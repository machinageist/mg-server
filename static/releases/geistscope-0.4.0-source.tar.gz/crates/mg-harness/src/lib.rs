/*******************************************************************
 * Filename:        lib.rs
 * Author:          Jeff
 * Date:            2026-05-15
 * Description:     Scoped AI harness endpoint dispatcher
 * Notes:           The harness accepts typed JSON invocations, applies
 *                  risk/scope policy, dispatches allowlisted tool endpoints,
 *                  and returns bounded JSON results for TUI or AI callers.
 *******************************************************************/

pub mod chat;

use std::collections::BTreeMap;
use std::fs;
use std::path::{Path, PathBuf};
use std::str::FromStr;
use std::time::{Duration, Instant};

use engagement::{
    AuthState, Engagement, Finding, Severity, Status, TrafficFilter, TrafficImportFormat,
};
use security_graph::{FileGraphStore, GraphStore, NodeKind};
use serde::{Deserialize, Serialize};
use serde_json::{Value, json};
use thiserror::Error;
use time::OffsetDateTime;
use time::format_description::well_known::Rfc3339;
use url::Url;

const HARNESS_VERSION: &str = "2026-05-15";
const MAX_MODEL_VISIBLE_BYTES: usize = 256 * 1024;

// Risk classes used by endpoint policy
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum RiskClass {
    ReadOnly,
    PassiveRemote,
    LowActive,
    HighActive,
    StateChange,
    Destructive,
}

// Status values returned to callers
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum EndpointStatus {
    Ok,
    Blocked,
    Error,
}

// JSON request accepted by the harness
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Invocation {
    pub endpoint: String,
    #[serde(default)]
    pub version: Option<String>,
    pub engagement: String,
    #[serde(default)]
    pub risk: Option<RiskClass>,
    #[serde(default)]
    pub reason: Option<String>,
    #[serde(default)]
    pub confirmed: bool,
    #[serde(default)]
    pub args: Value,
}

// JSON result returned by the harness
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EndpointResult {
    pub endpoint: String,
    pub status: EndpointStatus,
    pub risk: RiskClass,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub summary: Option<String>,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub output_files: Vec<String>,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub evidence_refs: Vec<String>,
    #[serde(default, skip_serializing_if = "BTreeMap::is_empty")]
    pub redactions: BTreeMap<String, usize>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub data: Option<Value>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub reason: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub policy: Option<String>,
}

// Collapsed tool-pack groups used to reduce model-visible tool sprawl while
// preserving specialist binaries behind reviewed pack interfaces.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ToolPack {
    CoreHarness,
    Reconx,
    ProtocolAudit,
    VulnScan,
    IdentityAudit,
    CloudAudit,
    ArtifactAudit,
    Eventing,
    RedteamLab,
}

// Exposure tier for endpoint registry consumers. Dispatch policy is unchanged;
// this metadata lets clients hide/repack tools before they are physically pruned.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ToolExposure {
    DefaultProfile,
    AdvancedProfile,
    LabOnly,
    ServiceInternal,
    RetiredPendingPack,
}

// Static description for an allowlisted endpoint
#[derive(Debug, Clone, Serialize)]
pub struct EndpointSpec {
    pub name: &'static str,
    pub risk: RiskClass,
    pub implemented: bool,
    pub description: &'static str,
    pub pack: ToolPack,
    pub exposure: ToolExposure,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub repurpose: Option<&'static str>,
}

// Runtime configuration for dispatch
#[derive(Debug, Clone)]
pub struct HarnessConfig {
    pub engagements_dir: PathBuf,
}

// Errors surfaced before a structured endpoint result can be produced
#[derive(Debug, Error)]
pub enum HarnessError {
    #[error("unknown endpoint: {0}")]
    UnknownEndpoint(String),
    #[error("invalid endpoint arguments: {0}")]
    InvalidArgs(String),
    #[error("io: {0}")]
    Io(#[from] std::io::Error),
    #[error("engagement: {0}")]
    Engagement(#[from] engagement::EngagementError),
    #[error("json: {0}")]
    Json(#[from] serde_json::Error),
    #[error("time format: {0}")]
    TimeFormat(#[from] time::error::Format),
    #[error("recon: {0}")]
    Recon(#[from] anyhow::Error),
    #[error("report: {0}")]
    Report(#[from] mg_report::ReportError),
    #[error("recopilot: {0}")]
    Recopilot(#[from] mg_recopilot::RecopilotError),
    #[error("aifuzz: {0}")]
    AiFuzz(#[from] mg_aifuzz::AiFuzzError),
    #[error("exploitgen: {0}")]
    ExploitGen(#[from] mg_exploitgen::ExploitGenError),
    #[error("graph: {0}")]
    Graph(#[from] security_graph::SecurityGraphError),
    #[error("session: {0}")]
    Session(#[from] session::SessionError),
    #[error("http: {0}")]
    Http(#[from] reqwest::Error),
}

impl HarnessConfig {
    // Build a config from an engagements directory
    pub fn new(engagements_dir: impl Into<PathBuf>) -> Self {
        Self {
            engagements_dir: engagements_dir.into(),
        }
    }
}

// Dispatch a single invocation through policy and endpoint handlers
pub async fn dispatch(cfg: &HarnessConfig, invocation: Invocation) -> EndpointResult {
    let endpoint = invocation.endpoint.clone();
    let spec = match endpoint_spec(&endpoint) {
        Some(spec) => spec,
        None => {
            return result_error(
                endpoint,
                RiskClass::ReadOnly,
                "endpoint.unknown",
                "unknown endpoint",
            );
        }
    };

    if let Some(requested_risk) = invocation.risk
        && requested_risk != spec.risk
    {
        return result_blocked(
            endpoint,
            spec.risk,
            "risk.mismatch",
            "invocation risk does not match endpoint risk",
        );
    }

    if let Some(version) = &invocation.version
        && version != HARNESS_VERSION
    {
        return result_blocked(
            endpoint,
            spec.risk,
            "version.unsupported",
            "invocation version is not supported by this harness",
        );
    }

    if matches!(spec.risk, RiskClass::Destructive) {
        return result_blocked(
            endpoint,
            spec.risk,
            "risk.destructive_blocked",
            "destructive endpoints are blocked",
        );
    }

    if matches!(spec.risk, RiskClass::HighActive | RiskClass::StateChange) && !invocation.confirmed
    {
        return result_blocked(
            endpoint,
            spec.risk,
            "risk.confirmation_required",
            "endpoint requires explicit confirmation",
        );
    }

    let dispatch_result = match endpoint.as_str() {
        "endpoint.registry" => Ok(endpoint_registry()),
        "engagement.open" => handle_engagement_open(cfg, &invocation).await,
        "engagement.status" => handle_engagement_status(cfg, &invocation).await,
        "scope.check" => handle_scope_check(cfg, &invocation).await,
        "recon.run" => handle_recon_run(cfg, &invocation).await,
        "session.set" => handle_session_set(cfg, &invocation).await,
        "session.get_headers" => handle_session_get_headers(cfg, &invocation).await,
        "request.import" => handle_request_import(cfg, &invocation).await,
        "request.search" => handle_request_search(cfg, &invocation).await,
        "request.read" => handle_request_read(cfg, &invocation).await,
        "request.replay" => handle_request_replay(cfg, &invocation).await,
        "graph.ingest" => handle_graph_ingest(cfg, &invocation).await,
        "graph.summary" => handle_graph_summary(cfg, &invocation).await,
        "graph.neighbors" => handle_graph_neighbors(cfg, &invocation).await,
        "chain.read" => handle_chain_read(cfg, &invocation).await,
        "report.generate" => handle_report_generate(cfg, &invocation).await,
        "report.disclose" => handle_report_disclose(cfg, &invocation).await,
        "re.analyze" => handle_re_analyze(cfg, &invocation).await,
        "re.read" => handle_re_read(cfg, &invocation).await,
        "aifuzz.run" => handle_aifuzz_run(cfg, &invocation).await,
        "aifuzz.consent" => handle_aifuzz_consent(cfg, &invocation).await,
        "exploit.scaffold" => handle_exploit_scaffold(cfg, &invocation).await,
        "finding.read" => handle_finding_read(cfg, &invocation).await,
        "finding.create" => handle_finding_create(cfg, &invocation).await,
        // ---- Subprocess-dispatched tool endpoints — table-driven, see SUBPROCESS_TOOLS
        ep if subprocess_tool_for(ep).is_some() => {
            handle_tool_binary(cfg, &invocation, spec.risk).await
        }
        _ => Ok(result_blocked(
            endpoint.clone(),
            spec.risk,
            "endpoint.not_implemented",
            "endpoint is registered but not implemented yet",
        )),
    };

    match dispatch_result {
        Ok(result) => result,
        Err(err) => result_error(endpoint, spec.risk, "endpoint.error", &err.to_string()),
    }
}

fn tool_pack_for_endpoint(endpoint: &str) -> ToolPack {
    match endpoint {
        "endpoint.registry"
        | "engagement.open"
        | "engagement.status"
        | "scope.check"
        | "session.set"
        | "session.get_headers"
        | "request.import"
        | "request.search"
        | "request.read"
        | "request.replay"
        | "graph.ingest"
        | "graph.summary"
        | "graph.neighbors"
        | "chain.read"
        | "finding.read"
        | "finding.create"
        | "report.generate"
        | "report.disclose"
        | "risk.rank" => ToolPack::CoreHarness,
        "whois.lookup" | "shodan.lookup" | "dns.history" | "breach.lookup"
        | "dork.run" | "github.search" | "cloud.enum" | "dns.enum"
        | "diff.run" | "timeline.generate" | "leak.monitor" | "recon.run" => ToolPack::Reconx,
        "tls.scan" | "ssh.audit" | "udp.scan" | "vhost.scan" | "graphql.scan" | "csp.analyze"
        | "cname.chain" | "http2.scan" | "grpc.scan" | "websocket.scan" | "smb.scan"
        | "smtp.enum" | "snmp.brute" | "crawl.run" | "probe.run" => ToolPack::ProtocolAudit,
        "xss.scan" | "sqli.scan" | "ssrf.scan" | "ssti.scan" | "xxe.scan" | "traversal.scan"
        | "redirect.scan" | "csrf.scan" | "smuggle.scan" | "cmdinject.scan" | "cache.poison"
        | "proto.pollute" | "deser.scan" | "openapi.scan" | "cors.scan"
        | "dns.rebind" | "oob.start" => ToolPack::VulnScan,
        "brute.run" | "authz.scan" | "oauth.analyze" | "session.audit" | "jwt.analyze" => {
            ToolPack::IdentityAudit
        }
        "aws.chain" | "gcp.chain" | "azure.chain" | "k8s.scan" | "docker.scan"
        | "serverless.chain" => ToolPack::CloudAudit,
        "apikey.extract" | "js.analyze" | "sourcemap.fetch" | "apk.analyze" | "ipa.analyze"
        | "metadata.extract" | "secret.validate" | "re.analyze" | "re.read"
        | "artifact.audit" => ToolPack::ArtifactAudit,
        "notify.start" => ToolPack::Eventing,
        "privesc.linux" | "privesc.windows" | "loot.run" | "exploit.scaffold" | "aifuzz.run"
        | "aifuzz.consent" => ToolPack::RedteamLab,
        _ => ToolPack::CoreHarness,
    }
}

fn tool_exposure_for_endpoint(endpoint: &str, risk: RiskClass) -> ToolExposure {
    match endpoint {
        "notify.start" => ToolExposure::ServiceInternal,
        "brute.run" | "snmp.brute" | "dns.rebind" => ToolExposure::RetiredPendingPack,
        "privesc.linux" | "privesc.windows" | "loot.run" | "exploit.scaffold" => {
            ToolExposure::LabOnly
        }
        "aifuzz.run" | "aifuzz.consent" | "oob.start" => ToolExposure::AdvancedProfile,
        _ if matches!(risk, RiskClass::HighActive | RiskClass::Destructive) => {
            ToolExposure::AdvancedProfile
        }
        _ => ToolExposure::DefaultProfile,
    }
}

fn endpoint_repurpose_note(endpoint: &str) -> Option<&'static str> {
    match endpoint {
        "brute.run" => Some(
            "Repurpose into mg-identity-audit as rate-limit, lockout, and credential-stuffing exposure analysis; remove standalone brute-force affordance from default profiles.",
        ),
        "snmp.brute" => Some(
            "Repurpose into mg-protocol-audit as conservative SNMP community exposure checks without brute-force defaults.",
        ),
        "dns.rebind" => Some(
            "Repurpose into mg-vuln-scan SSRF/OOB planning as a lab-gated payload strategy, not a default standalone generator.",
        ),
        "notify.start" => Some(
            "Fold into eventing/OOB service infrastructure used by scanners; do not expose as a model-selected tool.",
        ),
        "oob.start" => Some(
            "Fold into mg-vuln-scan as managed callback infrastructure for SSRF/injection confirmation.",
        ),
        "privesc.linux" => Some(
            "Repurpose local checks into redteam-lab artifact inventory and defensive persistence triage; keep automation lab-only.",
        ),
        "privesc.windows" => Some(
            "Repurpose local checks into redteam-lab artifact inventory and defensive persistence triage; keep automation lab-only.",
        ),
        "loot.run" => Some(
            "Repurpose parsers into artifact-audit evidence inventory/redaction helpers; remove post-exploitation collection posture from default profiles.",
        ),
        "exploit.scaffold" => Some(
            "Keep as redteam-lab/CVE reproduction scaffolding only; never expose as a default exploit-generation tool.",
        ),
        _ => None,
    }
}

// Return the allowlisted endpoint registry
pub fn registry() -> Vec<EndpointSpec> {
    vec![
        EndpointSpec {
            name: "endpoint.registry",
            risk: RiskClass::ReadOnly,
            implemented: true,
            description: "List harness endpoints, risk classes, and implementation status.",
            pack: tool_pack_for_endpoint("endpoint.registry"),
            exposure: tool_exposure_for_endpoint("endpoint.registry", RiskClass::ReadOnly),
            repurpose: endpoint_repurpose_note("endpoint.registry"),
        },
        EndpointSpec {
            name: "engagement.open",
            risk: RiskClass::ReadOnly,
            implemented: true,
            description: "Load engagement metadata, scope, and key workspace file paths.",
            pack: tool_pack_for_endpoint("engagement.open"),
            exposure: tool_exposure_for_endpoint("engagement.open", RiskClass::ReadOnly),
            repurpose: endpoint_repurpose_note("engagement.open"),
        },
        EndpointSpec {
            name: "engagement.status",
            risk: RiskClass::ReadOnly,
            implemented: true,
            description: "Summarize current engagement output files and counts.",
            pack: tool_pack_for_endpoint("engagement.status"),
            exposure: tool_exposure_for_endpoint("engagement.status", RiskClass::ReadOnly),
            repurpose: endpoint_repurpose_note("engagement.status"),
        },
        EndpointSpec {
            name: "scope.check",
            risk: RiskClass::ReadOnly,
            implemented: true,
            description: "Check whether a host or URL is in scope for an engagement.",
            pack: tool_pack_for_endpoint("scope.check"),
            exposure: tool_exposure_for_endpoint("scope.check", RiskClass::ReadOnly),
            repurpose: endpoint_repurpose_note("scope.check"),
        },
        EndpointSpec {
            name: "recon.run",
            risk: RiskClass::HighActive,
            implemented: true,
            description: "Run the scoped mg-recon pipeline after explicit confirmation.",
            pack: tool_pack_for_endpoint("recon.run"),
            exposure: tool_exposure_for_endpoint("recon.run", RiskClass::HighActive),
            repurpose: endpoint_repurpose_note("recon.run"),
        },
        EndpointSpec {
            name: "session.set",
            risk: RiskClass::StateChange,
            implemented: true,
            description: "Store a redaction-safe session profile using environment-variable references.",
            pack: tool_pack_for_endpoint("session.set"),
            exposure: tool_exposure_for_endpoint("session.set", RiskClass::StateChange),
            repurpose: endpoint_repurpose_note("session.set"),
        },
        EndpointSpec {
            name: "session.get_headers",
            risk: RiskClass::ReadOnly,
            implemented: true,
            description: "Resolve session auth headers and return only redacted header metadata.",
            pack: tool_pack_for_endpoint("session.get_headers"),
            exposure: tool_exposure_for_endpoint("session.get_headers", RiskClass::ReadOnly),
            repurpose: endpoint_repurpose_note("session.get_headers"),
        },
        EndpointSpec {
            name: "crawl.run",
            risk: RiskClass::LowActive,
            implemented: false,
            description: "Run crawler against scoped URLs.",
            pack: tool_pack_for_endpoint("crawl.run"),
            exposure: tool_exposure_for_endpoint("crawl.run", RiskClass::LowActive),
            repurpose: endpoint_repurpose_note("crawl.run"),
        },
        EndpointSpec {
            name: "probe.run",
            risk: RiskClass::LowActive,
            implemented: false,
            description: "Run passive and semi-active posture checks.",
            pack: tool_pack_for_endpoint("probe.run"),
            exposure: tool_exposure_for_endpoint("probe.run", RiskClass::LowActive),
            repurpose: endpoint_repurpose_note("probe.run"),
        },
        EndpointSpec {
            name: "request.import",
            risk: RiskClass::StateChange,
            implemented: true,
            description: "Import HAR, Burp XML, or Caido JSON traffic into the engagement corpus.",
            pack: tool_pack_for_endpoint("request.import"),
            exposure: tool_exposure_for_endpoint("request.import", RiskClass::StateChange),
            repurpose: endpoint_repurpose_note("request.import"),
        },
        EndpointSpec {
            name: "request.search",
            risk: RiskClass::ReadOnly,
            implemented: true,
            description: "Search the normalized request corpus with bounded filters.",
            pack: tool_pack_for_endpoint("request.search"),
            exposure: tool_exposure_for_endpoint("request.search", RiskClass::ReadOnly),
            repurpose: endpoint_repurpose_note("request.search"),
        },
        EndpointSpec {
            name: "request.read",
            risk: RiskClass::ReadOnly,
            implemented: true,
            description: "Read one normalized request record by request ID or prefix.",
            pack: tool_pack_for_endpoint("request.read"),
            exposure: tool_exposure_for_endpoint("request.read", RiskClass::ReadOnly),
            repurpose: endpoint_repurpose_note("request.read"),
        },
        EndpointSpec {
            name: "request.replay",
            risk: RiskClass::LowActive,
            implemented: true,
            description: "Replay one captured request and compare the response.",
            pack: tool_pack_for_endpoint("request.replay"),
            exposure: tool_exposure_for_endpoint("request.replay", RiskClass::LowActive),
            repurpose: endpoint_repurpose_note("request.replay"),
        },
        EndpointSpec {
            name: "fuzzer.plan",
            risk: RiskClass::ReadOnly,
            implemented: false,
            description: "Build a fuzz plan without sending traffic.",
            pack: tool_pack_for_endpoint("fuzzer.plan"),
            exposure: tool_exposure_for_endpoint("fuzzer.plan", RiskClass::ReadOnly),
            repurpose: endpoint_repurpose_note("fuzzer.plan"),
        },
        EndpointSpec {
            name: "fuzzer.run",
            risk: RiskClass::HighActive,
            implemented: false,
            description: "Run bounded fuzzing after explicit confirmation.",
            pack: tool_pack_for_endpoint("fuzzer.run"),
            exposure: tool_exposure_for_endpoint("fuzzer.run", RiskClass::HighActive),
            repurpose: endpoint_repurpose_note("fuzzer.run"),
        },
        EndpointSpec {
            name: "oob.allocate",
            risk: RiskClass::ReadOnly,
            implemented: false,
            description: "Allocate an OOB callback token.",
            pack: tool_pack_for_endpoint("oob.allocate"),
            exposure: tool_exposure_for_endpoint("oob.allocate", RiskClass::ReadOnly),
            repurpose: endpoint_repurpose_note("oob.allocate"),
        },
        EndpointSpec {
            name: "oob.poll",
            risk: RiskClass::PassiveRemote,
            implemented: false,
            description: "Poll OOB callback logs.",
            pack: tool_pack_for_endpoint("oob.poll"),
            exposure: tool_exposure_for_endpoint("oob.poll", RiskClass::PassiveRemote),
            repurpose: endpoint_repurpose_note("oob.poll"),
        },
        EndpointSpec {
            name: "graph.ingest",
            risk: RiskClass::ReadOnly,
            implemented: true,
            description: "Ingest current engagement artifacts into the local security graph.",
            pack: tool_pack_for_endpoint("graph.ingest"),
            exposure: tool_exposure_for_endpoint("graph.ingest", RiskClass::ReadOnly),
            repurpose: endpoint_repurpose_note("graph.ingest"),
        },
        EndpointSpec {
            name: "graph.summary",
            risk: RiskClass::ReadOnly,
            implemented: true,
            description: "Summarize the local security graph with bounded sample nodes.",
            pack: tool_pack_for_endpoint("graph.summary"),
            exposure: tool_exposure_for_endpoint("graph.summary", RiskClass::ReadOnly),
            repurpose: endpoint_repurpose_note("graph.summary"),
        },
        EndpointSpec {
            name: "graph.neighbors",
            risk: RiskClass::ReadOnly,
            implemented: true,
            description: "Read a bounded incoming/outgoing neighborhood for one graph node.",
            pack: tool_pack_for_endpoint("graph.neighbors"),
            exposure: tool_exposure_for_endpoint("graph.neighbors", RiskClass::ReadOnly),
            repurpose: endpoint_repurpose_note("graph.neighbors"),
        },
        EndpointSpec {
            name: "finding.create",
            risk: RiskClass::ReadOnly,
            implemented: true,
            description: "Create a finding skeleton from evidence references.",
            pack: tool_pack_for_endpoint("finding.create"),
            exposure: tool_exposure_for_endpoint("finding.create", RiskClass::ReadOnly),
            repurpose: endpoint_repurpose_note("finding.create"),
        },
        EndpointSpec {
            name: "finding.read",
            risk: RiskClass::ReadOnly,
            implemented: true,
            description: "Read one finding markdown file by finding ID.",
            pack: tool_pack_for_endpoint("finding.read"),
            exposure: tool_exposure_for_endpoint("finding.read", RiskClass::ReadOnly),
            repurpose: endpoint_repurpose_note("finding.read"),
        },
        EndpointSpec {
            name: "chain.read",
            risk: RiskClass::ReadOnly,
            implemented: true,
            description: "Read bounded exploit chain analysis artifacts.",
            pack: tool_pack_for_endpoint("chain.read"),
            exposure: tool_exposure_for_endpoint("chain.read", RiskClass::ReadOnly),
            repurpose: endpoint_repurpose_note("chain.read"),
        },
        EndpointSpec {
            name: "finding.replay",
            risk: RiskClass::LowActive,
            implemented: false,
            description: "Retest finding evidence.",
            pack: tool_pack_for_endpoint("finding.replay"),
            exposure: tool_exposure_for_endpoint("finding.replay", RiskClass::LowActive),
            repurpose: endpoint_repurpose_note("finding.replay"),
        },
        EndpointSpec {
            name: "report.generate",
            risk: RiskClass::ReadOnly,
            implemented: true,
            description: "Generate a bounty report from one local finding.",
            pack: tool_pack_for_endpoint("report.generate"),
            exposure: tool_exposure_for_endpoint("report.generate", RiskClass::ReadOnly),
            repurpose: endpoint_repurpose_note("report.generate"),
        },
        EndpointSpec {
            name: "report.disclose",
            risk: RiskClass::ReadOnly,
            implemented: true,
            description: "Draft a CVE writeup and disclosure email for one finding.",
            pack: tool_pack_for_endpoint("report.disclose"),
            exposure: tool_exposure_for_endpoint("report.disclose", RiskClass::ReadOnly),
            repurpose: endpoint_repurpose_note("report.disclose"),
        },
        EndpointSpec {
            name: "re.analyze",
            risk: RiskClass::ReadOnly,
            implemented: true,
            description: "Analyze decompiled pseudocode and write a Markdown + JSON pair.",
            pack: tool_pack_for_endpoint("re.analyze"),
            exposure: tool_exposure_for_endpoint("re.analyze", RiskClass::ReadOnly),
            repurpose: endpoint_repurpose_note("re.analyze"),
        },
        EndpointSpec {
            name: "re.read",
            risk: RiskClass::ReadOnly,
            implemented: true,
            description: "Read a previously generated RE analysis for one function.",
            pack: tool_pack_for_endpoint("re.read"),
            exposure: tool_exposure_for_endpoint("re.read", RiskClass::ReadOnly),
            repurpose: endpoint_repurpose_note("re.read"),
        },
        EndpointSpec {
            name: "aifuzz.consent",
            risk: RiskClass::StateChange,
            implemented: true,
            description: "Record adversarial AI-fuzz consent for one engagement.",
            pack: tool_pack_for_endpoint("aifuzz.consent"),
            exposure: tool_exposure_for_endpoint("aifuzz.consent", RiskClass::StateChange),
            repurpose: endpoint_repurpose_note("aifuzz.consent"),
        },
        EndpointSpec {
            name: "aifuzz.run",
            risk: RiskClass::HighActive,
            implemented: true,
            description: "Run a bounded prompt-injection fuzz pass against a scoped LLM endpoint.",
            pack: tool_pack_for_endpoint("aifuzz.run"),
            exposure: tool_exposure_for_endpoint("aifuzz.run", RiskClass::HighActive),
            repurpose: endpoint_repurpose_note("aifuzz.run"),
        },
        EndpointSpec {
            name: "exploit.scaffold",
            risk: RiskClass::ReadOnly,
            implemented: true,
            description: "Generate a Rust exploit project skeleton for one CVE under the engagement.",
            pack: tool_pack_for_endpoint("exploit.scaffold"),
            exposure: tool_exposure_for_endpoint("exploit.scaffold", RiskClass::ReadOnly),
            repurpose: endpoint_repurpose_note("exploit.scaffold"),
        },
        EndpointSpec {
            name: "risk.rank",
            risk: RiskClass::ReadOnly,
            implemented: false,
            description: "Rank targets and hypotheses from local evidence.",
            pack: tool_pack_for_endpoint("risk.rank"),
            exposure: tool_exposure_for_endpoint("risk.rank", RiskClass::ReadOnly),
            repurpose: endpoint_repurpose_note("risk.rank"),
        },
    ]
    .into_iter()
    .chain(SUBPROCESS_TOOLS.iter().map(|t| EndpointSpec {
        name: t.endpoint,
        risk: t.risk,
        implemented: true,
        description: t.description,
        pack: tool_pack_for_endpoint(t.endpoint),
        exposure: tool_exposure_for_endpoint(t.endpoint, t.risk),
        repurpose: endpoint_repurpose_note(t.endpoint),
    }))
    .collect()
}

// Return the spec for one endpoint name
fn endpoint_spec(name: &str) -> Option<EndpointSpec> {
    registry().into_iter().find(|spec| spec.name == name)
}

// Handle endpoint.registry
fn endpoint_registry() -> EndpointResult {
    EndpointResult {
        endpoint: "endpoint.registry".into(),
        status: EndpointStatus::Ok,
        risk: RiskClass::ReadOnly,
        summary: Some("endpoint registry loaded".into()),
        output_files: Vec::new(),
        evidence_refs: Vec::new(),
        redactions: BTreeMap::new(),
        data: Some(json!({
            "version": HARNESS_VERSION,
            "endpoints": registry(),
        })),
        reason: None,
        policy: None,
    }
}

// Handle graph.ingest
async fn handle_graph_ingest(
    cfg: &HarnessConfig,
    invocation: &Invocation,
) -> Result<EndpointResult, HarnessError> {
    let eng = load_engagement(cfg, &invocation.engagement)?;
    let report = security_graph::ingest_engagement(&eng)?;
    let nodes_added = report.nodes_added();
    let edges_added = report.edges_added();
    let store = FileGraphStore::for_engagement(&eng);
    let nodes_path = store.nodes_path();
    let edges_path = store.edges_path();

    let _ = eng.audit(
        "mg-harness",
        &eng.meta.target,
        Some(&format!(
            "endpoint=graph.ingest nodes_added={nodes_added} edges_added={edges_added}"
        )),
    );

    Ok(EndpointResult {
        endpoint: invocation.endpoint.clone(),
        status: EndpointStatus::Ok,
        risk: RiskClass::ReadOnly,
        summary: Some(format!(
            "graph ingested: {nodes_added} new nodes, {edges_added} new edges"
        )),
        output_files: vec![display_path(&nodes_path), display_path(&edges_path)],
        evidence_refs: vec![format!("evidence://{}/graph", invocation.engagement)],
        redactions: BTreeMap::new(),
        data: Some(json!({
            "report": report,
            "nodes_added": nodes_added,
            "edges_added": edges_added,
        })),
        reason: None,
        policy: None,
    })
}

// Handle graph.summary
async fn handle_graph_summary(
    cfg: &HarnessConfig,
    invocation: &Invocation,
) -> Result<EndpointResult, HarnessError> {
    let eng = load_engagement(cfg, &invocation.engagement)?;
    let sample_limit = optional_usize(&invocation.args, "sample_limit", 10)?.min(50);
    let store = FileGraphStore::for_engagement(&eng);
    let summary = store.summary(sample_limit)?;
    let nodes_path = store.nodes_path();
    let edges_path = store.edges_path();

    let _ = eng.audit(
        "mg-harness",
        &eng.meta.target,
        Some(&format!(
            "endpoint=graph.summary nodes={} edges={}",
            summary.node_count, summary.edge_count
        )),
    );

    Ok(EndpointResult {
        endpoint: invocation.endpoint.clone(),
        status: EndpointStatus::Ok,
        risk: RiskClass::ReadOnly,
        summary: Some(format!(
            "graph summary: {} nodes, {} edges",
            summary.node_count, summary.edge_count
        )),
        output_files: vec![display_path(&nodes_path), display_path(&edges_path)],
        evidence_refs: vec![format!("evidence://{}/graph", invocation.engagement)],
        redactions: BTreeMap::new(),
        data: Some(json!(summary)),
        reason: None,
        policy: None,
    })
}

// Handle graph.neighbors
async fn handle_graph_neighbors(
    cfg: &HarnessConfig,
    invocation: &Invocation,
) -> Result<EndpointResult, HarnessError> {
    let eng = load_engagement(cfg, &invocation.engagement)?;
    let node_id = if let Some(node_id) = optional_string_opt(&invocation.args, "node_id")? {
        node_id
    } else {
        let kind = NodeKind::from_str(&required_string(&invocation.args, "kind")?)?;
        let key = required_string(&invocation.args, "key")?;
        security_graph::node_id(kind, &key)
    };
    let limit = optional_usize(&invocation.args, "limit", 25)?.min(100);
    let store = FileGraphStore::for_engagement(&eng);
    let neighbors = store.neighbors(&node_id, limit)?;

    let _ = eng.audit(
        "mg-harness",
        &eng.meta.target,
        Some(&format!(
            "endpoint=graph.neighbors node_id={} count={}",
            node_id,
            neighbors.neighbors.len()
        )),
    );

    Ok(EndpointResult {
        endpoint: invocation.endpoint.clone(),
        status: EndpointStatus::Ok,
        risk: RiskClass::ReadOnly,
        summary: Some(format!(
            "graph neighbors: {} neighbor(s) for {}",
            neighbors.neighbors.len(),
            node_id
        )),
        output_files: vec![
            display_path(&store.nodes_path()),
            display_path(&store.edges_path()),
        ],
        evidence_refs: vec![format!(
            "evidence://{}/graph/{}",
            invocation.engagement, node_id
        )],
        redactions: BTreeMap::new(),
        data: Some(json!(neighbors)),
        reason: None,
        policy: None,
    })
}

// Handle engagement.open
async fn handle_engagement_open(
    cfg: &HarnessConfig,
    invocation: &Invocation,
) -> Result<EndpointResult, HarnessError> {
    let eng = load_engagement(cfg, &invocation.engagement)?;
    let scope = eng.scope()?;
    let recon_dir = display_path(&eng.recon_dir());
    let crawl_dir = display_path(&eng.crawl_dir());
    let findings_dir = display_path(&eng.findings_dir());
    let traffic_dir = display_path(&eng.traffic_dir());
    let summary_path = eng.recon_dir().join("summary.json");
    let priorities_path = eng.recon_dir().join("priorities.json");
    let probe_path = eng.recon_dir().join("probe-report.json");
    let traffic_corpus_path = eng.traffic_corpus_path();

    let data = json!({
        "meta": eng.meta,
        "scope": scope,
        "paths": {
            "root": display_path(&eng.root),
            "recon": recon_dir,
            "crawl": crawl_dir,
            "findings": findings_dir,
            "traffic": traffic_dir,
            "traffic_corpus": display_path(&traffic_corpus_path),
            "summary": display_path(&summary_path),
            "priorities": display_path(&priorities_path),
            "probe_report": display_path(&probe_path),
        },
        "exists": {
            "summary": summary_path.exists(),
            "priorities": priorities_path.exists(),
            "probe_report": probe_path.exists(),
            "traffic_corpus": traffic_corpus_path.exists(),
        }
    });

    let _ = eng.audit(
        "mg-harness",
        &eng.meta.target,
        Some("endpoint=engagement.open"),
    );

    Ok(EndpointResult {
        endpoint: invocation.endpoint.clone(),
        status: EndpointStatus::Ok,
        risk: RiskClass::ReadOnly,
        summary: Some(format!("engagement {} loaded", invocation.engagement)),
        output_files: Vec::new(),
        evidence_refs: Vec::new(),
        redactions: BTreeMap::new(),
        data: Some(data),
        reason: None,
        policy: None,
    })
}

// Handle engagement.status
async fn handle_engagement_status(
    cfg: &HarnessConfig,
    invocation: &Invocation,
) -> Result<EndpointResult, HarnessError> {
    let eng = load_engagement(cfg, &invocation.engagement)?;
    let recon_dir = eng.recon_dir();
    let crawl_dir = eng.crawl_dir();
    let findings_dir = eng.findings_dir();
    let audit_path = eng.root.join("audit.log");
    let summary_path = recon_dir.join("summary.json");
    let priorities_path = recon_dir.join("priorities.json");
    let probe_path = recon_dir.join("probe-report.json");
    let traffic_corpus_path = eng.traffic_corpus_path();

    let data = json!({
        "engagement": invocation.engagement,
        "target": eng.meta.target,
        "files": {
            "summary": file_state(&summary_path),
            "priorities": file_state(&priorities_path),
            "probe_report": file_state(&probe_path),
            "traffic_corpus": file_state(&traffic_corpus_path),
            "audit_log": file_state(&audit_path),
        },
        "counts": {
            "crawl_hosts": count_dirs(&crawl_dir),
            "traffic_requests": count_lines(&traffic_corpus_path),
            "findings": count_files_with_extension(&findings_dir, "md"),
            "fuzz_reports": count_files_with_prefix_suffix(&recon_dir, "fuzz-", ".json"),
            "audit_lines": count_lines(&audit_path),
        },
        "paths": {
            "root": display_path(&eng.root),
            "recon": display_path(&recon_dir),
            "crawl": display_path(&crawl_dir),
            "findings": display_path(&findings_dir),
            "traffic": display_path(&eng.traffic_dir()),
        }
    });

    let _ = eng.audit(
        "mg-harness",
        &eng.meta.target,
        Some("endpoint=engagement.status"),
    );

    Ok(EndpointResult {
        endpoint: invocation.endpoint.clone(),
        status: EndpointStatus::Ok,
        risk: RiskClass::ReadOnly,
        summary: Some(format!(
            "engagement {} status loaded",
            invocation.engagement
        )),
        output_files: vec![display_path(&summary_path), display_path(&priorities_path)],
        evidence_refs: Vec::new(),
        redactions: BTreeMap::new(),
        data: Some(data),
        reason: None,
        policy: None,
    })
}

// Handle finding.create
async fn handle_finding_create(
    cfg: &HarnessConfig,
    invocation: &Invocation,
) -> Result<EndpointResult, HarnessError> {
    let eng = load_engagement(cfg, &invocation.engagement)?;
    let title = required_string(&invocation.args, "title")?;
    let raw_target = required_string(&invocation.args, "target")?;
    let normalized_target = normalize_target(&raw_target)?;
    if !eng.scope()?.is_in_scope(&normalized_target) {
        return Ok(result_blocked(
            invocation.endpoint.clone(),
            RiskClass::ReadOnly,
            "scope.default_deny",
            "finding target is out of scope",
        ));
    }

    let severity = parse_severity(&optional_string(&invocation.args, "severity", "medium")?)?;
    let mut body = optional_string(&invocation.args, "body", &Finding::skeleton_body())?;
    let evidence_refs = optional_string_array(&invocation.args, "evidence_refs")?;
    if !evidence_refs.is_empty() {
        body.push_str("\n## Evidence references\n\n");
        for evidence_ref in &evidence_refs {
            body.push_str(&format!("- `{evidence_ref}`\n"));
        }
    }

    let finding = Finding {
        id: Finding::next_id(&eng.findings_dir())?,
        title: title.clone(),
        severity,
        status: Status::Draft,
        target: raw_target,
        created: now_rfc3339()?,
        body,
    };
    let path = finding.write_to(&eng.findings_dir())?;

    let _ = eng.audit(
        "mg-harness",
        &normalized_target,
        Some(&format!("endpoint=finding.create path={}", path.display())),
    );

    Ok(EndpointResult {
        endpoint: invocation.endpoint.clone(),
        status: EndpointStatus::Ok,
        risk: RiskClass::ReadOnly,
        summary: Some(format!("created finding draft: {title}")),
        output_files: vec![display_path(&path)],
        evidence_refs,
        redactions: BTreeMap::new(),
        data: Some(json!({
            "finding_path": display_path(&path),
            "id": finding.id,
            "severity": finding.severity.as_str(),
            "status": finding.status.as_str(),
        })),
        reason: None,
        policy: None,
    })
}

// Handle finding.read
async fn handle_finding_read(
    cfg: &HarnessConfig,
    invocation: &Invocation,
) -> Result<EndpointResult, HarnessError> {
    let eng = load_engagement(cfg, &invocation.engagement)?;
    let finding_id = required_string(&invocation.args, "finding_id")?;
    validate_finding_id(&finding_id)?;
    let path = find_finding_path(&eng.findings_dir(), &finding_id)?;
    let raw = fs::read_to_string(&path)?;
    let (markdown, truncated) = truncate_model_visible(&raw);
    let mut redactions = BTreeMap::new();
    if truncated {
        redactions.insert(
            "truncated_bytes".into(),
            raw.len().saturating_sub(markdown.len()),
        );
    }

    let _ = eng.audit(
        "mg-harness",
        &finding_id,
        Some(&format!("endpoint=finding.read path={}", path.display())),
    );

    Ok(EndpointResult {
        endpoint: invocation.endpoint.clone(),
        status: EndpointStatus::Ok,
        risk: RiskClass::ReadOnly,
        summary: Some(format!("finding {finding_id} loaded")),
        output_files: vec![display_path(&path)],
        evidence_refs: vec![format!(
            "evidence://{}/finding/{}",
            invocation.engagement, finding_id
        )],
        redactions,
        data: Some(json!({
            "finding_id": finding_id,
            "path": display_path(&path),
            "markdown": markdown,
            "truncated": truncated,
        })),
        reason: None,
        policy: None,
    })
}

// Handle scope.check
async fn handle_scope_check(
    cfg: &HarnessConfig,
    invocation: &Invocation,
) -> Result<EndpointResult, HarnessError> {
    let eng = load_engagement(cfg, &invocation.engagement)?;
    let scope = eng.scope()?;
    let raw_target = required_string(&invocation.args, "target")?;
    let normalized = normalize_target(&raw_target)?;
    let in_scope = scope.is_in_scope(&normalized);
    let data = json!({
        "target": raw_target,
        "normalized_target": normalized,
        "in_scope": in_scope,
    });

    let _ = eng.audit(
        "mg-harness",
        &normalized,
        Some(&format!("endpoint=scope.check in_scope={in_scope}")),
    );

    Ok(EndpointResult {
        endpoint: invocation.endpoint.clone(),
        status: EndpointStatus::Ok,
        risk: RiskClass::ReadOnly,
        summary: Some(format!("scope check: {normalized} -> {in_scope}")),
        output_files: Vec::new(),
        evidence_refs: Vec::new(),
        redactions: BTreeMap::new(),
        data: Some(data),
        reason: None,
        policy: None,
    })
}

// Handle recon.run
async fn handle_recon_run(
    cfg: &HarnessConfig,
    invocation: &Invocation,
) -> Result<EndpointResult, HarnessError> {
    let eng_root = Engagement::path_for_name(&cfg.engagements_dir, &invocation.engagement)?;
    let eng = Engagement::load(&eng_root)?;
    ensure_target_in_scope(&eng, &eng.meta.target)?;

    let force = optional_bool(&invocation.args, "force", false)?;
    let concurrency = optional_usize(&invocation.args, "concurrency", 100)?;
    let timeout_ms = optional_u64(&invocation.args, "timeout_ms", 5000)?;
    let ports = optional_string(&invocation.args, "ports", "1-1024")?;
    let (port_start, port_end) = parse_ports(&ports)?;

    if concurrency == 0 {
        return Err(HarnessError::InvalidArgs(
            "concurrency must be at least 1".into(),
        ));
    }

    let run_cfg = mg_recon::orchestrator::RunConfig {
        engagement_name: invocation.engagement.clone(),
        eng_root: eng_root.clone(),
        force,
        concurrency,
        timeout_ms,
        port_start,
        port_end,
    };

    mg_recon::orchestrator::run(run_cfg).await?;

    let summary_path = eng_root.join("recon").join("summary.json");
    let _ = eng.audit(
        "mg-harness",
        &eng.meta.target,
        Some("endpoint=recon.run status=ok"),
    );

    Ok(EndpointResult {
        endpoint: invocation.endpoint.clone(),
        status: EndpointStatus::Ok,
        risk: RiskClass::HighActive,
        summary: Some(format!("recon completed for {}", invocation.engagement)),
        output_files: vec![display_path(&summary_path)],
        evidence_refs: vec![format!(
            "evidence://{}/recon/summary",
            invocation.engagement
        )],
        redactions: BTreeMap::new(),
        data: Some(json!({
            "summary_path": display_path(&summary_path),
        })),
        reason: None,
        policy: None,
    })
}

// Handle session.set
async fn handle_session_set(
    cfg: &HarnessConfig,
    invocation: &Invocation,
) -> Result<EndpointResult, HarnessError> {
    reject_plaintext_secret_args(&invocation.args)?;
    let eng = load_engagement(cfg, &invocation.engagement)?;
    let token_env = optional_string_opt(&invocation.args, "token_env")?;
    let password_env = optional_string_opt(&invocation.args, "password_env")?;
    let login_url = optional_string_opt(&invocation.args, "login_url")?;
    let username = optional_string_opt(&invocation.args, "username")?;
    let token_header = optional_string(&invocation.args, "token_header", "Authorization")?;
    let token_prefix = optional_string(&invocation.args, "token_prefix", "Bearer")?;
    let login_method = optional_string(
        &invocation.args,
        "login_method",
        if token_env.is_some() { "token" } else { "form" },
    )?;
    validate_login_method(&login_method)?;

    if token_env.is_none() && password_env.is_none() {
        return Err(HarnessError::InvalidArgs(
            "session.set requires token_env or password_env".into(),
        ));
    }
    if password_env.is_some() && login_url.is_none() {
        return Err(HarnessError::InvalidArgs(
            "password_env requires login_url".into(),
        ));
    }

    let config = session::SessionConfig {
        username,
        password_env,
        login_url,
        login_method: login_method.clone(),
        token_header,
        token_prefix,
        token_env,
        session_cookie: None,
        token_refresh_url: optional_string_opt(&invocation.args, "token_refresh_url")?,
        valid_until: None,
    };
    let path = session::save_session_config(&eng, &config)?;
    let _ = eng.audit(
        "mg-harness",
        &eng.meta.target,
        Some(&format!("endpoint=session.set method={login_method}")),
    );

    Ok(EndpointResult {
        endpoint: invocation.endpoint.clone(),
        status: EndpointStatus::Ok,
        risk: RiskClass::StateChange,
        summary: Some(format!(
            "stored {login_method} session profile for {}",
            invocation.engagement
        )),
        output_files: vec![display_path(&path)],
        evidence_refs: Vec::new(),
        redactions: BTreeMap::new(),
        data: Some(json!({
            "path": display_path(&path),
            "login_method": login_method,
            "has_token_env": config.token_env.is_some(),
            "has_password_env": config.password_env.is_some(),
            "has_login_url": config.login_url.is_some(),
        })),
        reason: None,
        policy: None,
    })
}

// Handle session.get_headers
async fn handle_session_get_headers(
    cfg: &HarnessConfig,
    invocation: &Invocation,
) -> Result<EndpointResult, HarnessError> {
    let eng = load_engagement(cfg, &invocation.engagement)?;
    match session::load_session_config(&eng) {
        Ok(_) => {}
        Err(session::SessionError::NotConfigured) => {
            return Ok(EndpointResult {
                endpoint: invocation.endpoint.clone(),
                status: EndpointStatus::Ok,
                risk: RiskClass::ReadOnly,
                summary: Some("no session profile configured".into()),
                output_files: Vec::new(),
                evidence_refs: Vec::new(),
                redactions: BTreeMap::new(),
                data: Some(json!({
                    "configured": false,
                    "headers": {},
                    "header_count": 0,
                })),
                reason: None,
                policy: None,
            });
        }
        Err(err) => return Err(err.into()),
    }

    let headers = session::get_auth_headers_sync(&eng)?;
    let redacted_headers: BTreeMap<String, String> = headers
        .iter()
        .map(|(name, _)| (name.as_str().to_string(), "<redacted>".to_string()))
        .collect();
    let header_count = redacted_headers.len();
    let mut redactions = BTreeMap::new();
    redactions.insert("headers".into(), header_count);
    let _ = eng.audit(
        "mg-harness",
        &eng.meta.target,
        Some(&format!(
            "endpoint=session.get_headers header_count={}",
            header_count
        )),
    );

    Ok(EndpointResult {
        endpoint: invocation.endpoint.clone(),
        status: EndpointStatus::Ok,
        risk: RiskClass::ReadOnly,
        summary: Some(format!(
            "resolved {} redacted auth header(s)",
            redacted_headers.len()
        )),
        output_files: Vec::new(),
        evidence_refs: Vec::new(),
        redactions,
        data: Some(json!({
            "configured": true,
            "headers": redacted_headers,
            "header_count": header_count,
        })),
        reason: None,
        policy: None,
    })
}

// Handle request.import
async fn handle_request_import(
    cfg: &HarnessConfig,
    invocation: &Invocation,
) -> Result<EndpointResult, HarnessError> {
    let eng = load_engagement(cfg, &invocation.engagement)?;
    let file = required_string(&invocation.args, "file")?;
    let format = optional_string(&invocation.args, "format", "auto")?;
    let summary = engagement::import_traffic_file(
        &eng,
        Path::new(&file),
        TrafficImportFormat::parse(&format)?,
    )?;
    let _ = eng.audit(
        "mg-harness",
        &eng.meta.target,
        Some(&format!(
            "endpoint=request.import imported={} skipped={} format={}",
            summary.imported, summary.skipped, summary.format
        )),
    );

    Ok(EndpointResult {
        endpoint: invocation.endpoint.clone(),
        status: EndpointStatus::Ok,
        risk: RiskClass::StateChange,
        summary: Some(format!(
            "imported {} request(s), skipped {} duplicate(s)",
            summary.imported, summary.skipped
        )),
        output_files: vec![summary.corpus_path.clone()],
        evidence_refs: vec![format!("evidence://{}/traffic", invocation.engagement)],
        redactions: BTreeMap::new(),
        data: Some(json!({ "summary": summary })),
        reason: None,
        policy: None,
    })
}

// Handle request.search
async fn handle_request_search(
    cfg: &HarnessConfig,
    invocation: &Invocation,
) -> Result<EndpointResult, HarnessError> {
    let eng = load_engagement(cfg, &invocation.engagement)?;
    let limit = optional_usize(&invocation.args, "limit", 25)?.min(100);
    let filter = TrafficFilter {
        host: optional_string_opt(&invocation.args, "host")?,
        method: optional_string_opt(&invocation.args, "method")?,
        path_contains: optional_string_opt(&invocation.args, "path_contains")?,
        status: optional_u16_opt(&invocation.args, "status")?,
        mime: optional_string_opt(&invocation.args, "mime")?,
        auth_state: optional_auth_state(&invocation.args, "auth_state")?,
        source: optional_string_opt(&invocation.args, "source")?,
        limit: Some(limit),
    };
    let records = engagement::search_traffic_records(&eng, &filter)?;
    let items: Vec<Value> = records.iter().map(traffic_record_summary).collect();
    let _ = eng.audit(
        "mg-harness",
        &eng.meta.target,
        Some(&format!(
            "endpoint=request.search count={} limit={limit}",
            items.len()
        )),
    );

    Ok(EndpointResult {
        endpoint: invocation.endpoint.clone(),
        status: EndpointStatus::Ok,
        risk: RiskClass::ReadOnly,
        summary: Some(format!("request search returned {} record(s)", items.len())),
        output_files: vec![display_path(&eng.traffic_corpus_path())],
        evidence_refs: vec![format!("evidence://{}/traffic", invocation.engagement)],
        redactions: BTreeMap::new(),
        data: Some(json!({
            "count": items.len(),
            "limit": limit,
            "requests": items,
        })),
        reason: None,
        policy: None,
    })
}

// Handle request.read
async fn handle_request_read(
    cfg: &HarnessConfig,
    invocation: &Invocation,
) -> Result<EndpointResult, HarnessError> {
    let eng = load_engagement(cfg, &invocation.engagement)?;
    let request_id = required_string(&invocation.args, "request_id")?;
    let include_raw = optional_bool(&invocation.args, "include_raw", false)?;
    let record = engagement::find_traffic_record(&eng, &request_id)?;
    let mut data = traffic_record_detail(&record);
    if include_raw {
        data["raw_request_template"] = json!(model_safe_raw_request(&record));
    }
    let _ = eng.audit(
        "mg-harness",
        &record.host,
        Some(&format!("endpoint=request.read request_id={}", record.id)),
    );

    Ok(EndpointResult {
        endpoint: invocation.endpoint.clone(),
        status: EndpointStatus::Ok,
        risk: RiskClass::ReadOnly,
        summary: Some(format!("request {} loaded", record.id)),
        output_files: vec![display_path(&eng.traffic_corpus_path())],
        evidence_refs: vec![format!(
            "evidence://{}/traffic/{}",
            invocation.engagement, record.id
        )],
        redactions: BTreeMap::new(),
        data: Some(data),
        reason: None,
        policy: None,
    })
}

// Handle request.replay
async fn handle_request_replay(
    cfg: &HarnessConfig,
    invocation: &Invocation,
) -> Result<EndpointResult, HarnessError> {
    let eng = load_engagement(cfg, &invocation.engagement)?;
    let request_id = required_string(&invocation.args, "request_id")?;
    let timeout_ms = optional_u64(&invocation.args, "timeout_ms", 15_000)?;
    let insecure = optional_bool(&invocation.args, "insecure", false)?;
    let record = engagement::find_traffic_record(&eng, &request_id)?;
    ensure_target_in_scope(&eng, &record.url)?;

    let session_headers = session::get_auth_headers_sync(&eng)?;
    let client = reqwest::Client::builder()
        .timeout(Duration::from_millis(timeout_ms))
        .redirect(reqwest::redirect::Policy::none())
        .danger_accept_invalid_certs(insecure)
        .default_headers(session_headers)
        .user_agent("mg-harness/0.1 request.replay")
        .build()?;

    let method = reqwest::Method::from_bytes(record.method.as_bytes())
        .map_err(|err| HarnessError::InvalidArgs(format!("invalid method: {err}")))?;
    let mut builder = client.request(method, &record.url);
    for header in &record.request_headers {
        if header.redacted || should_skip_replay_header(&header.name) {
            continue;
        }
        builder = builder.header(header.name.as_str(), header.value.as_str());
    }
    if let Some(body) = &record.request_body {
        builder = builder.body(read_body_ref(&eng, body)?);
    }

    let started = Instant::now();
    let response = builder.send().await?;
    let elapsed_ms = started.elapsed().as_millis() as u64;
    let status = response.status().as_u16();
    let headers = response_headers_to_pairs(response.headers());
    let body = read_limited_response_bytes(response, MAX_MODEL_VISIBLE_BYTES).await?;
    let replay_fingerprint =
        engagement::response_fingerprint_from_parts(status, &headers, &body, None);
    let original_fingerprint = record
        .response
        .as_ref()
        .map(engagement::response_fingerprint_from_record);
    let diff = original_fingerprint
        .as_ref()
        .map(|original| engagement::diff_response_fingerprints(original, &replay_fingerprint));

    fs::create_dir_all(eng.traffic_replays_dir())?;
    let replayed_at = now_rfc3339()?;
    let report_path = eng.traffic_replays_dir().join(format!(
        "{}-{}.json",
        record.id,
        safe_timestamp(&replayed_at)
    ));
    let report = json!({
        "engagement": invocation.engagement,
        "request_id": record.id.clone(),
        "url": redact_sensitive_url(&record.url),
        "method": record.method.clone(),
        "replayed_at": replayed_at,
        "elapsed_ms": elapsed_ms,
        "original": original_fingerprint,
        "replay": replay_fingerprint,
        "diff": diff,
    });
    fs::write(&report_path, serde_json::to_string_pretty(&report)?)?;

    let _ = eng.audit(
        "mg-harness",
        &record.host,
        Some(&format!(
            "endpoint=request.replay request_id={} status={} elapsed_ms={elapsed_ms}",
            record.id, status
        )),
    );

    Ok(EndpointResult {
        endpoint: invocation.endpoint.clone(),
        status: EndpointStatus::Ok,
        risk: RiskClass::LowActive,
        summary: Some(format!("replayed {} -> {}", record.id, status)),
        output_files: vec![display_path(&report_path)],
        evidence_refs: vec![
            format!("evidence://{}/traffic/{}", invocation.engagement, record.id),
            format!(
                "evidence://{}/traffic/replay/{}",
                invocation.engagement, record.id
            ),
        ],
        redactions: BTreeMap::new(),
        data: Some(report),
        reason: None,
        policy: None,
    })
}

// Handle chain.read
async fn handle_chain_read(
    cfg: &HarnessConfig,
    invocation: &Invocation,
) -> Result<EndpointResult, HarnessError> {
    let eng = load_engagement(cfg, &invocation.engagement)?;
    let json_path = eng.recon_dir().join("chain-analysis.json");
    let md_path = eng.recon_dir().join("chain-analysis.md");
    if !json_path.exists() && !md_path.exists() {
        return Ok(result_blocked(
            invocation.endpoint.clone(),
            RiskClass::ReadOnly,
            "chain.missing",
            "chain-analysis artifacts are not present",
        ));
    }

    let json_raw = fs::read_to_string(&json_path).unwrap_or_default();
    let md_raw = fs::read_to_string(&md_path).unwrap_or_default();
    let (json_text, json_truncated) = truncate_model_visible(&json_raw);
    let (markdown, md_truncated) = truncate_model_visible(&md_raw);
    let mut redactions = BTreeMap::new();
    if json_truncated {
        redactions.insert(
            "chain_json_truncated_bytes".into(),
            json_raw.len().saturating_sub(json_text.len()),
        );
    }
    if md_truncated {
        redactions.insert(
            "chain_markdown_truncated_bytes".into(),
            md_raw.len().saturating_sub(markdown.len()),
        );
    }

    let _ = eng.audit("mg-harness", &eng.meta.target, Some("endpoint=chain.read"));

    Ok(EndpointResult {
        endpoint: invocation.endpoint.clone(),
        status: EndpointStatus::Ok,
        risk: RiskClass::ReadOnly,
        summary: Some("chain analysis loaded".into()),
        output_files: vec![display_path(&json_path), display_path(&md_path)],
        evidence_refs: vec![format!(
            "evidence://{}/recon/chain-analysis",
            invocation.engagement
        )],
        redactions,
        data: Some(json!({
            "json_path": display_path(&json_path),
            "markdown_path": display_path(&md_path),
            "chain_json": json_text,
            "markdown": markdown,
            "json_truncated": json_truncated,
            "markdown_truncated": md_truncated,
        })),
        reason: None,
        policy: None,
    })
}

// Handle report.generate
async fn handle_report_generate(
    cfg: &HarnessConfig,
    invocation: &Invocation,
) -> Result<EndpointResult, HarnessError> {
    let finding_id = required_string(&invocation.args, "finding_id")?;
    let model = optional_string(&invocation.args, "model", "claude-sonnet-4-6")?;
    let ollama_model = optional_string(&invocation.args, "ollama_model", "llama3.2")?;
    let offline = optional_bool(&invocation.args, "offline", false)?;
    let force = optional_bool(&invocation.args, "force", false)?;
    let output = mg_report::generate_report(&mg_report::ReportConfig {
        engagements_dir: cfg.engagements_dir.clone(),
        engagement: invocation.engagement.clone(),
        finding_id: finding_id.clone(),
        model,
        ollama_model,
        offline,
        force,
    })
    .await?;

    Ok(EndpointResult {
        endpoint: invocation.endpoint.clone(),
        status: EndpointStatus::Ok,
        risk: RiskClass::ReadOnly,
        summary: Some(format!("report generated for finding {finding_id}")),
        output_files: vec![display_path(&output.report_path)],
        evidence_refs: vec![format!(
            "evidence://{}/report/{}",
            invocation.engagement, output.finding_id
        )],
        redactions: BTreeMap::new(),
        data: Some(json!({
            "finding_id": output.finding_id,
            "finding_path": display_path(&output.finding_path),
            "report_path": display_path(&output.report_path),
            "cvss_vector": output.cvss_vector,
            "cvss_score": output.cvss_score,
            "severity": output.severity,
            "generated": output.generated,
        })),
        reason: None,
        policy: None,
    })
}

// Handle report.disclose
async fn handle_report_disclose(
    cfg: &HarnessConfig,
    invocation: &Invocation,
) -> Result<EndpointResult, HarnessError> {
    let finding_id = required_string(&invocation.args, "finding_id")?;
    let vendor = required_string(&invocation.args, "vendor")?;
    let contact = required_string(&invocation.args, "contact")?;
    let model = optional_string(&invocation.args, "model", "claude-sonnet-4-6")?;
    let ollama_model = optional_string(&invocation.args, "ollama_model", "llama3.2")?;
    let offline = optional_bool(&invocation.args, "offline", false)?;
    let force = optional_bool(&invocation.args, "force", false)?;
    let timeline_days = optional_u32(
        &invocation.args,
        "timeline_days",
        mg_report::DiscloseConfig::default_timeline_days(),
    )?;

    let output = mg_report::disclose_finding(&mg_report::DiscloseConfig {
        engagements_dir: cfg.engagements_dir.clone(),
        engagement: invocation.engagement.clone(),
        finding_id: finding_id.clone(),
        vendor,
        contact,
        timeline_days,
        model,
        ollama_model,
        offline,
        force,
    })
    .await?;

    Ok(EndpointResult {
        endpoint: invocation.endpoint.clone(),
        status: EndpointStatus::Ok,
        risk: RiskClass::ReadOnly,
        summary: Some(format!(
            "disclosure drafted for finding {finding_id} ({} day window)",
            output.timeline_days
        )),
        output_files: vec![
            display_path(&output.cve_writeup_path),
            display_path(&output.disclosure_email_path),
        ],
        evidence_refs: vec![format!(
            "evidence://{}/disclosure/{}",
            invocation.engagement, output.finding_id
        )],
        redactions: BTreeMap::new(),
        data: Some(json!({
            "finding_id": output.finding_id,
            "finding_path": display_path(&output.finding_path),
            "cve_writeup_path": display_path(&output.cve_writeup_path),
            "disclosure_email_path": display_path(&output.disclosure_email_path),
            "cvss_vector": output.cvss_vector,
            "cvss_score": output.cvss_score,
            "severity": output.severity,
            "timeline_days": output.timeline_days,
            "reported_on": output.reported_on,
            "generated": output.generated,
        })),
        reason: None,
        policy: None,
    })
}

// Handle re.analyze
async fn handle_re_analyze(
    cfg: &HarnessConfig,
    invocation: &Invocation,
) -> Result<EndpointResult, HarnessError> {
    let binary = required_string(&invocation.args, "binary")?;
    let function = required_string(&invocation.args, "function")?;
    let model = optional_string(&invocation.args, "model", "claude-sonnet-4-6")?;
    let ollama_model = optional_string(&invocation.args, "ollama_model", "llama3.2")?;
    let offline = optional_bool(&invocation.args, "offline", false)?;
    let force = optional_bool(&invocation.args, "force", false)?;

    let output = mg_recopilot::analyze_function(&mg_recopilot::AnalyzeConfig {
        engagements_dir: cfg.engagements_dir.clone(),
        engagement: invocation.engagement.clone(),
        binary: binary.clone(),
        function: function.clone(),
        model,
        ollama_model,
        offline,
        force,
    })
    .await?;

    Ok(EndpointResult {
        endpoint: invocation.endpoint.clone(),
        status: EndpointStatus::Ok,
        risk: RiskClass::ReadOnly,
        summary: Some(format!("re analysis written for {binary}/{function}")),
        output_files: vec![
            display_path(&output.markdown_path),
            display_path(&output.json_path),
        ],
        evidence_refs: vec![format!(
            "evidence://{}/re/{}/{}",
            invocation.engagement, output.binary, output.function
        )],
        redactions: BTreeMap::new(),
        data: Some(json!({
            "binary": output.binary,
            "function": output.function,
            "raw_pseudocode_path": display_path(&output.raw_pseudocode_path),
            "markdown_path": display_path(&output.markdown_path),
            "json_path": display_path(&output.json_path),
            "generated": output.generated,
        })),
        reason: None,
        policy: None,
    })
}

// Handle re.read
async fn handle_re_read(
    cfg: &HarnessConfig,
    invocation: &Invocation,
) -> Result<EndpointResult, HarnessError> {
    let binary = required_string(&invocation.args, "binary")?;
    let function = required_string(&invocation.args, "function")?;
    let read = mg_recopilot::read_analysis(
        &cfg.engagements_dir,
        &invocation.engagement,
        &binary,
        &function,
    )?;
    let (markdown, truncated) = truncate_model_visible(&read.markdown);

    Ok(EndpointResult {
        endpoint: invocation.endpoint.clone(),
        status: EndpointStatus::Ok,
        risk: RiskClass::ReadOnly,
        summary: Some(format!("re analysis read for {binary}/{function}")),
        output_files: Vec::new(),
        evidence_refs: vec![format!(
            "evidence://{}/re/{}/{}",
            invocation.engagement, read.binary, read.function
        )],
        redactions: BTreeMap::new(),
        data: Some(json!({
            "binary": read.binary,
            "function": read.function,
            "markdown": markdown,
            "markdown_truncated": truncated,
            "json": read.json,
        })),
        reason: None,
        policy: None,
    })
}

// Handle aifuzz.consent
async fn handle_aifuzz_consent(
    cfg: &HarnessConfig,
    invocation: &Invocation,
) -> Result<EndpointResult, HarnessError> {
    let path = mg_aifuzz::record_consent(&cfg.engagements_dir, &invocation.engagement)?;
    Ok(EndpointResult {
        endpoint: invocation.endpoint.clone(),
        status: EndpointStatus::Ok,
        risk: RiskClass::StateChange,
        summary: Some(format!(
            "aifuzz consent recorded for {}",
            invocation.engagement
        )),
        output_files: vec![display_path(&path)],
        evidence_refs: Vec::new(),
        redactions: BTreeMap::new(),
        data: Some(json!({ "consent_path": display_path(&path) })),
        reason: None,
        policy: None,
    })
}

// Handle aifuzz.run
async fn handle_aifuzz_run(
    cfg: &HarnessConfig,
    invocation: &Invocation,
) -> Result<EndpointResult, HarnessError> {
    let template = required_string(&invocation.args, "template")?;
    let base_url = required_string(&invocation.args, "base_url")?;
    let sentinels = optional_string_opt(&invocation.args, "sentinels")?;
    let max_attempts = optional_usize(
        &invocation.args,
        "max_attempts",
        mg_aifuzz::FuzzConfig::default_max_attempts(),
    )?;
    let rate_ms = optional_u64(
        &invocation.args,
        "rate_ms",
        mg_aifuzz::FuzzConfig::default_rate_ms(),
    )?;
    let timeout_ms = optional_u64(
        &invocation.args,
        "timeout_ms",
        mg_aifuzz::FuzzConfig::default_timeout_ms(),
    )?;
    let raw_categories = optional_string_array(&invocation.args, "categories")?;
    let mut categories = Vec::new();
    for raw in raw_categories {
        let parsed = payload_engine::PromptInjectionCategory::from_name(&raw).ok_or_else(|| {
            HarnessError::InvalidArgs(format!("unknown prompt-injection category `{raw}`"))
        })?;
        categories.push(parsed);
    }

    let output = mg_aifuzz::run(&mg_aifuzz::FuzzConfig {
        engagements_dir: cfg.engagements_dir.clone(),
        engagement: invocation.engagement.clone(),
        template_path: PathBuf::from(template),
        base_url,
        categories,
        max_attempts,
        rate_ms,
        timeout_ms,
        sentinels_path: sentinels.map(PathBuf::from),
    })
    .await?;

    Ok(EndpointResult {
        endpoint: invocation.endpoint.clone(),
        status: EndpointStatus::Ok,
        risk: RiskClass::HighActive,
        summary: Some(format!(
            "aifuzz run {} attempts={} hits={}",
            output.run_id, output.attempts, output.hits
        )),
        output_files: vec![display_path(&output.output_path)],
        evidence_refs: vec![format!(
            "evidence://{}/aifuzz/{}",
            invocation.engagement, output.run_id
        )],
        redactions: BTreeMap::new(),
        data: Some(json!({
            "run_id": output.run_id,
            "output_path": display_path(&output.output_path),
            "attempts": output.attempts,
            "hits": output.hits,
        })),
        reason: None,
        policy: None,
    })
}

// Handle exploit.scaffold
async fn handle_exploit_scaffold(
    cfg: &HarnessConfig,
    invocation: &Invocation,
) -> Result<EndpointResult, HarnessError> {
    let cve = required_string(&invocation.args, "cve")?;
    let cve_description = required_string(&invocation.args, "cve_description")?;
    let target_env = required_string(&invocation.args, "target_env")?;
    let model = optional_string(&invocation.args, "model", "claude-sonnet-4-6")?;
    let ollama_model = optional_string(&invocation.args, "ollama_model", "llama3.2")?;
    let offline = optional_bool(&invocation.args, "offline", false)?;
    let force = optional_bool(&invocation.args, "force", false)?;

    let output = mg_exploitgen::scaffold_exploit(&mg_exploitgen::ScaffoldConfig {
        engagements_dir: cfg.engagements_dir.clone(),
        engagement: invocation.engagement.clone(),
        cve,
        cve_description_path: PathBuf::from(cve_description),
        target_env_path: PathBuf::from(target_env),
        model,
        ollama_model,
        offline,
        force,
    })
    .await?;

    Ok(EndpointResult {
        endpoint: invocation.endpoint.clone(),
        status: EndpointStatus::Ok,
        risk: RiskClass::ReadOnly,
        summary: Some(format!("scaffold ready for {}", output.cve)),
        output_files: vec![
            display_path(&output.exploit_dir),
            display_path(&output.runbook_path),
        ],
        evidence_refs: vec![format!(
            "evidence://{}/exploits/{}",
            invocation.engagement, output.cve
        )],
        redactions: BTreeMap::new(),
        data: Some(json!({
            "cve": output.cve,
            "crate_name": output.crate_name,
            "exploit_dir": display_path(&output.exploit_dir),
            "runbook_path": display_path(&output.runbook_path),
            "generated": output.generated,
        })),
        reason: None,
        policy: None,
    })
}

// Wall-clock limit for subprocess execution; tools that need longer should write
// progress files and exit, then be polled separately
const TOOL_SUBPROCESS_TIMEOUT: Duration = Duration::from_secs(300);
// Maximum bytes captured from each of stdout / stderr — protects the harness from
// gigabyte log dumps. Truncated output gets a marker line appended.
const TOOL_SUBPROCESS_OUTPUT_CAP: usize = 64 * 1024;

// Truncate output bytes to the cap, returning a UTF-8 string with a marker if cut
fn cap_subprocess_output(buf: &[u8]) -> String {
    if buf.len() <= TOOL_SUBPROCESS_OUTPUT_CAP {
        return String::from_utf8_lossy(buf).trim().to_string();
    }
    let mut s = String::from_utf8_lossy(&buf[..TOOL_SUBPROCESS_OUTPUT_CAP]).into_owned();
    s.push_str(&format!(
        "\n... [truncated: {} bytes hidden]",
        buf.len() - TOOL_SUBPROCESS_OUTPUT_CAP
    ));
    s
}

// Run a tool binary as a subprocess, forwarding safe string params from the request
async fn run_tool_binary(
    binary: &str,
    req: &Invocation,
    eng: &Engagement,
    engagements_dir: &str,
) -> anyhow::Result<serde_json::Value> {
    use tokio::process::Command;

    let mut cmd = Command::new(binary);
    if let Some(subcommand) = tool_subcommand_for_endpoint(&req.endpoint) {
        cmd.arg(subcommand);
    }
    cmd.arg(&eng.meta.name)
        .arg("--engagements-dir")
        .arg(engagements_dir);
    // Kill the child on parent drop so timeouts actually free the process
    cmd.kill_on_drop(true);

    // Forward extra string params from args as --key value pairs
    if let Some(obj) = req.args.as_object() {
        for (k, v) in obj {
            if k == "engagement" || k == "engagements_dir" {
                continue;
            }
            if let Some(s) = v.as_str() {
                cmd.arg(format!("--{}", k.replace('_', "-"))).arg(s);
            }
        }
    }

    let exec = cmd.output();
    let output = match tokio::time::timeout(TOOL_SUBPROCESS_TIMEOUT, exec).await {
        Ok(res) => res?,
        Err(_) => {
            return Ok(json!({
                "success": false,
                "exit_code": serde_json::Value::Null,
                "stdout": "",
                "stderr": format!(
                    "tool subprocess timed out after {}s",
                    TOOL_SUBPROCESS_TIMEOUT.as_secs()
                ),
                "timed_out": true,
            }));
        }
    };
    Ok(json!({
        "success": output.status.success(),
        "exit_code": output.status.code(),
        "stdout": cap_subprocess_output(&output.stdout),
        "stderr": cap_subprocess_output(&output.stderr),
    }))
}

// Subprocess-dispatched tool spec: one row per (endpoint, binary, risk, description)
struct SubprocessTool {
    endpoint: &'static str,
    binary: &'static str,
    risk: RiskClass,
    description: &'static str,
}

// Single source of truth for the 67 subprocess-dispatched tool endpoints.
// Dispatch, registry entries, and the binary lookup all derive from this table —
// adding or renaming a tool only touches one row here.
const SUBPROCESS_TOOLS: &[SubprocessTool] = &[
    // ---- Passive recon
    SubprocessTool {
        endpoint: "whois.lookup",
        binary: "mg-whois",
        risk: RiskClass::PassiveRemote,
        description: "Look up WHOIS registration data for a domain.",
    },
    SubprocessTool {
        endpoint: "shodan.lookup",
        binary: "mg-shodan",
        risk: RiskClass::PassiveRemote,
        description: "Query Shodan for host intelligence.",
    },
    SubprocessTool {
        endpoint: "dns.history",
        binary: "mg-dns-history",
        risk: RiskClass::PassiveRemote,
        description: "Retrieve passive DNS history for a domain.",
    },
    SubprocessTool {
        endpoint: "breach.lookup",
        binary: "mg-breach",
        risk: RiskClass::PassiveRemote,
        description: "Look up breach data for a target domain.",
    },
    SubprocessTool {
        endpoint: "dork.run",
        binary: "mg-google-dork",
        risk: RiskClass::PassiveRemote,
        description: "Run Google-dork queries for target exposure.",
    },
    SubprocessTool {
        endpoint: "github.search",
        binary: "mg-github",
        risk: RiskClass::PassiveRemote,
        description: "Search GitHub for secrets and target references.",
    },
    SubprocessTool {
        endpoint: "cloud.enum",
        binary: "mg-cloud-enum",
        risk: RiskClass::PassiveRemote,
        description: "Enumerate cloud-storage buckets and resources.",
    },
    SubprocessTool {
        endpoint: "dns.enum",
        binary: "mg-dns-enum",
        risk: RiskClass::PassiveRemote,
        description: "Enumerate DNS records and subdomains.",
    },
    SubprocessTool {
        endpoint: "diff.run",
        binary: "mg-diff",
        risk: RiskClass::PassiveRemote,
        description: "Diff two engagement snapshots for change detection.",
    },
    SubprocessTool {
        endpoint: "timeline.generate",
        binary: "mg-timeline",
        risk: RiskClass::PassiveRemote,
        description: "Generate a timeline of engagement events.",
    },
    SubprocessTool {
        endpoint: "apikey.extract",
        binary: "mg-artifact-audit",
        risk: RiskClass::PassiveRemote,
        description: "Extract API keys from crawled or imported content.",
    },
    SubprocessTool {
        endpoint: "js.analyze",
        binary: "mg-artifact-audit",
        risk: RiskClass::PassiveRemote,
        description: "Analyze JavaScript files for secrets and endpoints.",
    },
    SubprocessTool {
        endpoint: "sourcemap.fetch",
        binary: "mg-artifact-audit",
        risk: RiskClass::PassiveRemote,
        description: "Fetch and reconstruct source maps from a target.",
    },
    SubprocessTool {
        endpoint: "apk.analyze",
        binary: "mg-artifact-audit",
        risk: RiskClass::PassiveRemote,
        description: "Static-analyze an Android APK for secrets and endpoints.",
    },
    SubprocessTool {
        endpoint: "ipa.analyze",
        binary: "mg-artifact-audit",
        risk: RiskClass::PassiveRemote,
        description: "Static-analyze an iOS IPA for secrets and endpoints.",
    },
    SubprocessTool {
        endpoint: "metadata.extract",
        binary: "mg-artifact-audit",
        risk: RiskClass::PassiveRemote,
        description: "Extract metadata from documents and images.",
    },
    SubprocessTool {
        endpoint: "artifact.audit",
        binary: "mg-artifact-audit",
        risk: RiskClass::PassiveRemote,
        description: "Run multiple artifact analyzers in one pass (types: js, sourcemap, apikey, metadata, apk, ipa).",
    },
    SubprocessTool {
        endpoint: "leak.monitor",
        binary: "mg-leak-monitor",
        risk: RiskClass::PassiveRemote,
        description: "Continuously monitor leak sources for target exposure.",
    },
    // ---- Semi-active probes
    SubprocessTool {
        endpoint: "tls.scan",
        binary: "mg-tls-scan",
        risk: RiskClass::LowActive,
        description: "Scan TLS configuration and certificate chain.",
    },
    SubprocessTool {
        endpoint: "ssh.audit",
        binary: "mg-ssh-audit",
        risk: RiskClass::LowActive,
        description: "Audit SSH ciphers, KEX, and host-key algorithms.",
    },
    SubprocessTool {
        endpoint: "udp.scan",
        binary: "mg-udp-scan",
        risk: RiskClass::LowActive,
        description: "Probe common UDP services on a scoped host.",
    },
    SubprocessTool {
        endpoint: "vhost.scan",
        binary: "mg-vhost",
        risk: RiskClass::LowActive,
        description: "Discover virtual hosts on a scoped IP.",
    },
    SubprocessTool {
        endpoint: "graphql.scan",
        binary: "mg-graphql",
        risk: RiskClass::LowActive,
        description: "Introspect a GraphQL endpoint for schema and misconfigs.",
    },
    SubprocessTool {
        endpoint: "csp.analyze",
        binary: "mg-csp",
        risk: RiskClass::LowActive,
        description: "Analyze Content-Security-Policy headers for weaknesses.",
    },
    SubprocessTool {
        endpoint: "cname.chain",
        binary: "mg-cname-chain",
        risk: RiskClass::LowActive,
        description: "Trace CNAME chains for dangling-record exposure.",
    },
    SubprocessTool {
        endpoint: "dns.rebind",
        binary: "mg-dns-rebind",
        risk: RiskClass::LowActive,
        description: "Generate DNS-rebinding payloads for a target.",
    },
    SubprocessTool {
        endpoint: "http2.scan",
        binary: "mg-http2",
        risk: RiskClass::LowActive,
        description: "Probe HTTP/2 and HTTP/3 support and misconfigs.",
    },
    SubprocessTool {
        endpoint: "grpc.scan",
        binary: "mg-grpc",
        risk: RiskClass::LowActive,
        description: "Enumerate gRPC services and methods.",
    },
    SubprocessTool {
        endpoint: "websocket.scan",
        binary: "mg-websocket",
        risk: RiskClass::LowActive,
        description: "Passively check WebSocket upgrade and origin policy.",
    },
    // ---- Active vuln scanners
    SubprocessTool {
        endpoint: "xss.scan",
        binary: "mg-webscan",
        risk: RiskClass::HighActive,
        description: "Scan for reflected and stored XSS vulnerabilities.",
    },
    SubprocessTool {
        endpoint: "sqli.scan",
        binary: "mg-webscan",
        risk: RiskClass::HighActive,
        description: "Scan for SQL injection vulnerabilities.",
    },
    SubprocessTool {
        endpoint: "ssrf.scan",
        binary: "mg-webscan",
        risk: RiskClass::HighActive,
        description: "Scan for server-side request forgery vulnerabilities.",
    },
    SubprocessTool {
        endpoint: "ssti.scan",
        binary: "mg-webscan",
        risk: RiskClass::HighActive,
        description: "Scan for server-side template injection vulnerabilities.",
    },
    SubprocessTool {
        endpoint: "xxe.scan",
        binary: "mg-webscan",
        risk: RiskClass::HighActive,
        description: "Scan for XML external entity injection vulnerabilities.",
    },
    SubprocessTool {
        endpoint: "traversal.scan",
        binary: "mg-webscan",
        risk: RiskClass::HighActive,
        description: "Scan for path-traversal vulnerabilities.",
    },
    SubprocessTool {
        endpoint: "redirect.scan",
        binary: "mg-webscan",
        risk: RiskClass::HighActive,
        description: "Scan for open-redirect vulnerabilities.",
    },
    SubprocessTool {
        endpoint: "csrf.scan",
        binary: "mg-webscan",
        risk: RiskClass::HighActive,
        description: "Scan for CSRF vulnerabilities.",
    },
    SubprocessTool {
        endpoint: "smuggle.scan",
        binary: "mg-webscan",
        risk: RiskClass::HighActive,
        description: "Scan for HTTP request-smuggling vulnerabilities.",
    },
    SubprocessTool {
        endpoint: "cmdinject.scan",
        binary: "mg-webscan",
        risk: RiskClass::HighActive,
        description: "Scan for OS command-injection vulnerabilities.",
    },
    SubprocessTool {
        endpoint: "cache.poison",
        binary: "mg-webscan",
        risk: RiskClass::HighActive,
        description: "Probe for web-cache poisoning vulnerabilities.",
    },
    SubprocessTool {
        endpoint: "proto.pollute",
        binary: "mg-webscan",
        risk: RiskClass::HighActive,
        description: "Probe for prototype-pollution vulnerabilities.",
    },
    SubprocessTool {
        endpoint: "deser.scan",
        binary: "mg-webscan",
        risk: RiskClass::HighActive,
        description: "Scan for insecure-deserialization vulnerabilities.",
    },
    SubprocessTool {
        endpoint: "brute.run",
        binary: "mg-brute",
        risk: RiskClass::HighActive,
        description: "Run credential brute-force against a scoped endpoint.",
    },
    SubprocessTool {
        endpoint: "authz.scan",
        binary: "mg-authz",
        risk: RiskClass::HighActive,
        description: "Scan for broken access-control and IDOR vulnerabilities.",
    },
    SubprocessTool {
        endpoint: "aws.chain",
        binary: "mg-aws",
        risk: RiskClass::HighActive,
        description: "Run AWS privilege-escalation chain checks.",
    },
    SubprocessTool {
        endpoint: "gcp.chain",
        binary: "mg-gcp",
        risk: RiskClass::HighActive,
        description: "Run GCP privilege-escalation chain checks.",
    },
    SubprocessTool {
        endpoint: "azure.chain",
        binary: "mg-azure",
        risk: RiskClass::HighActive,
        description: "Run Azure privilege-escalation chain checks.",
    },
    SubprocessTool {
        endpoint: "k8s.scan",
        binary: "mg-k8s",
        risk: RiskClass::HighActive,
        description: "Scan Kubernetes cluster for misconfigurations.",
    },
    SubprocessTool {
        endpoint: "docker.scan",
        binary: "mg-docker",
        risk: RiskClass::HighActive,
        description: "Scan Docker daemon and images for misconfigurations.",
    },
    SubprocessTool {
        endpoint: "serverless.chain",
        binary: "mg-serverless",
        risk: RiskClass::HighActive,
        description: "Probe serverless functions for privilege-escalation chains.",
    },
    SubprocessTool {
        endpoint: "secret.validate",
        binary: "mg-secret-validate",
        risk: RiskClass::HighActive,
        description: "Validate discovered secrets against live APIs.",
    },
    SubprocessTool {
        endpoint: "openapi.scan",
        binary: "mg-openapi",
        risk: RiskClass::HighActive,
        description: "Scan an OpenAPI spec and its endpoints for vulnerabilities.",
    },
    SubprocessTool {
        endpoint: "oauth.analyze",
        binary: "mg-oauth",
        risk: RiskClass::HighActive,
        description: "Analyze OAuth flows for misconfigurations and attacks.",
    },
    SubprocessTool {
        endpoint: "session.audit",
        binary: "mg-session-audit",
        risk: RiskClass::HighActive,
        description: "Audit session management for fixation and weak tokens.",
    },
    SubprocessTool {
        endpoint: "smb.scan",
        binary: "mg-smb",
        risk: RiskClass::HighActive,
        description: "Scan SMB shares for access and misconfigurations.",
    },
    SubprocessTool {
        endpoint: "smtp.enum",
        binary: "mg-smtp",
        risk: RiskClass::HighActive,
        description: "Enumerate SMTP users and relay configuration.",
    },
    SubprocessTool {
        endpoint: "snmp.brute",
        binary: "mg-snmp",
        risk: RiskClass::HighActive,
        description: "Brute-force SNMP community strings.",
    },
    SubprocessTool {
        endpoint: "cors.scan",
        binary: "mg-webscan",
        risk: RiskClass::HighActive,
        description: "Exploit CORS misconfigurations.",
    },
    SubprocessTool {
        endpoint: "jwt.analyze",
        binary: "mg-jwt",
        risk: RiskClass::HighActive,
        description: "Analyze JWT tokens for weak algorithms and key confusion.",
    },
    // ---- OOB and notification
    SubprocessTool {
        endpoint: "oob.start",
        binary: "mg-oob",
        risk: RiskClass::HighActive,
        description: "Start an OOB callback listener for SSRF and injection detection.",
    },
    SubprocessTool {
        endpoint: "takeover.scan",
        binary: "mg-takeover",
        risk: RiskClass::HighActive,
        description: "Scan for subdomain-takeover opportunities.",
    },
    SubprocessTool {
        endpoint: "notify.start",
        binary: "mg-notify",
        risk: RiskClass::HighActive,
        description: "Start a notification listener for async tool callbacks.",
    },
    // ---- Destructive / post-exploitation
    SubprocessTool {
        endpoint: "privesc.linux",
        binary: "mg-privesc-linux",
        risk: RiskClass::Destructive,
        description: "Run Linux privilege-escalation checks and automation.",
    },
    SubprocessTool {
        endpoint: "privesc.windows",
        binary: "mg-privesc-windows",
        risk: RiskClass::Destructive,
        description: "Run Windows privilege-escalation checks and automation.",
    },
    SubprocessTool {
        endpoint: "loot.run",
        binary: "mg-loot",
        risk: RiskClass::Destructive,
        description: "Collect and export post-exploitation loot.",
    },
];

// Look up the subprocess tool entry for an endpoint name
fn subprocess_tool_for(endpoint: &str) -> Option<&'static SubprocessTool> {
    SUBPROCESS_TOOLS.iter().find(|t| t.endpoint == endpoint)
}

// Map endpoint name to tool binary name; panics for unmapped endpoints since
// the dispatcher guards against them.
fn tool_binary_for_endpoint(endpoint: &str) -> &'static str {
    subprocess_tool_for(endpoint)
        .unwrap_or_else(|| panic!("unmapped tool endpoint: {endpoint}"))
        .binary
}

// Return the subcommand to invoke under a merged binary, if any.
// Used by run_tool_binary to call `mg-artifact-audit <sub> ...` instead of
// the legacy single-purpose binaries.
fn tool_subcommand_for_endpoint(endpoint: &str) -> Option<&'static str> {
    match endpoint {
        "js.analyze" => Some("js"),
        "sourcemap.fetch" => Some("sourcemap"),
        "apikey.extract" => Some("apikey"),
        "metadata.extract" => Some("metadata"),
        "apk.analyze" => Some("apk"),
        "ipa.analyze" => Some("ipa"),
        "artifact.audit" => Some("audit"),
        // mg-webscan — merged active web-vuln scanners
        "xss.scan" => Some("xss"),
        "sqli.scan" => Some("sqli"),
        "ssrf.scan" => Some("ssrf"),
        "ssti.scan" => Some("ssti"),
        "xxe.scan" => Some("xxe"),
        "traversal.scan" => Some("traversal"),
        "redirect.scan" => Some("redirect"),
        "csrf.scan" => Some("csrf"),
        "cmdinject.scan" => Some("cmdinject"),
        "cors.scan" => Some("cors"),
        "cache.poison" => Some("cache-poison"),
        "proto.pollute" => Some("proto-pollute"),
        "deser.scan" => Some("deser"),
        "smuggle.scan" => Some("smuggle"),
        _ => None,
    }
}

// Dispatch an invocation to a tool binary subprocess
async fn handle_tool_binary(
    cfg: &HarnessConfig,
    invocation: &Invocation,
    risk: RiskClass,
) -> Result<EndpointResult, HarnessError> {
    let eng = load_engagement(cfg, &invocation.engagement)?;
    let binary = tool_binary_for_endpoint(&invocation.endpoint);
    let engagements_dir = cfg.engagements_dir.display().to_string();
    let data = run_tool_binary(binary, invocation, &eng, &engagements_dir).await?;
    let success = data["success"].as_bool().unwrap_or(false);
    let status = if success {
        EndpointStatus::Ok
    } else {
        EndpointStatus::Error
    };
    let summary = format!(
        "{} exit_code={}",
        invocation.endpoint,
        data["exit_code"]
            .as_i64()
            .map(|c| c.to_string())
            .unwrap_or_else(|| "none".into())
    );

    let _ = eng.audit(
        "mg-harness",
        &eng.meta.target,
        Some(&format!(
            "endpoint={} binary={binary} success={success}",
            invocation.endpoint
        )),
    );

    Ok(EndpointResult {
        endpoint: invocation.endpoint.clone(),
        status,
        risk,
        summary: Some(summary),
        output_files: Vec::new(),
        evidence_refs: Vec::new(),
        redactions: BTreeMap::new(),
        data: Some(data),
        reason: None,
        policy: None,
    })
}

// Load engagement by name
fn load_engagement(cfg: &HarnessConfig, name: &str) -> Result<Engagement, HarnessError> {
    Ok(Engagement::load_named(&cfg.engagements_dir, name)?)
}

// Ensure a target is in the loaded engagement scope
fn ensure_target_in_scope(eng: &Engagement, target: &str) -> Result<(), HarnessError> {
    let normalized = normalize_target(target)?;
    if !eng.scope()?.is_in_scope(&normalized) {
        return Err(HarnessError::InvalidArgs(format!(
            "target {normalized} is out of scope"
        )));
    }
    Ok(())
}

// Extract a required string argument
fn required_string(args: &Value, key: &str) -> Result<String, HarnessError> {
    args.get(key)
        .and_then(Value::as_str)
        .map(str::to_string)
        .ok_or_else(|| HarnessError::InvalidArgs(format!("missing string arg `{key}`")))
}

// Extract an optional string argument
fn optional_string(args: &Value, key: &str, default: &str) -> Result<String, HarnessError> {
    match args.get(key) {
        Some(value) => value
            .as_str()
            .map(str::to_string)
            .ok_or_else(|| HarnessError::InvalidArgs(format!("arg `{key}` must be a string"))),
        None => Ok(default.to_string()),
    }
}

// Extract an optional string argument as Option
fn optional_string_opt(args: &Value, key: &str) -> Result<Option<String>, HarnessError> {
    match args.get(key) {
        Some(Value::Null) | None => Ok(None),
        Some(value) => value
            .as_str()
            .map(|value| Some(value.to_string()))
            .ok_or_else(|| HarnessError::InvalidArgs(format!("arg `{key}` must be a string"))),
    }
}

// Validate supported session login methods
fn validate_login_method(method: &str) -> Result<(), HarnessError> {
    match method {
        "token" | "form" | "oauth_client_credentials" => Ok(()),
        other => Err(HarnessError::InvalidArgs(format!(
            "unsupported login method `{other}`"
        ))),
    }
}

// Reject direct plaintext secret fields in model-visible invocations
fn reject_plaintext_secret_args(args: &Value) -> Result<(), HarnessError> {
    for key in ["password", "token", "api_key", "session_cookie"] {
        if args.get(key).is_some() {
            return Err(HarnessError::InvalidArgs(format!(
                "arg `{key}` is not allowed; use an environment-variable reference"
            )));
        }
    }
    Ok(())
}

// Extract an optional bool argument
fn optional_bool(args: &Value, key: &str, default: bool) -> Result<bool, HarnessError> {
    match args.get(key) {
        Some(value) => value
            .as_bool()
            .ok_or_else(|| HarnessError::InvalidArgs(format!("arg `{key}` must be a bool"))),
        None => Ok(default),
    }
}

// Extract an optional u64 argument
fn optional_u64(args: &Value, key: &str, default: u64) -> Result<u64, HarnessError> {
    match args.get(key) {
        Some(value) => value
            .as_u64()
            .ok_or_else(|| HarnessError::InvalidArgs(format!("arg `{key}` must be a u64"))),
        None => Ok(default),
    }
}

// Extract an optional usize argument
fn optional_usize(args: &Value, key: &str, default: usize) -> Result<usize, HarnessError> {
    let value = optional_u64(args, key, default as u64)?;
    usize::try_from(value)
        .map_err(|_| HarnessError::InvalidArgs(format!("arg `{key}` is too large")))
}

// Extract an optional u32 argument
fn optional_u32(args: &Value, key: &str, default: u32) -> Result<u32, HarnessError> {
    let value = optional_u64(args, key, default as u64)?;
    u32::try_from(value).map_err(|_| HarnessError::InvalidArgs(format!("arg `{key}` is too large")))
}

// Extract an optional u16 argument
fn optional_u16_opt(args: &Value, key: &str) -> Result<Option<u16>, HarnessError> {
    let Some(value) = args.get(key) else {
        return Ok(None);
    };
    let raw = value
        .as_u64()
        .ok_or_else(|| HarnessError::InvalidArgs(format!("arg `{key}` must be a u16")))?;
    let parsed = u16::try_from(raw)
        .map_err(|_| HarnessError::InvalidArgs(format!("arg `{key}` is too large")))?;
    Ok(Some(parsed))
}

// Extract an optional traffic auth state argument
fn optional_auth_state(args: &Value, key: &str) -> Result<Option<AuthState>, HarnessError> {
    let Some(raw) = optional_string_opt(args, key)? else {
        return Ok(None);
    };
    match raw.as_str() {
        "unknown" => Ok(Some(AuthState::Unknown)),
        "anonymous" => Ok(Some(AuthState::Anonymous)),
        "authenticated" => Ok(Some(AuthState::Authenticated)),
        other => Err(HarnessError::InvalidArgs(format!(
            "unknown auth_state `{other}`"
        ))),
    }
}

// Extract an optional array of strings
fn optional_string_array(args: &Value, key: &str) -> Result<Vec<String>, HarnessError> {
    let Some(value) = args.get(key) else {
        return Ok(Vec::new());
    };
    let Some(values) = value.as_array() else {
        return Err(HarnessError::InvalidArgs(format!(
            "arg `{key}` must be an array"
        )));
    };
    values
        .iter()
        .map(|value| {
            value.as_str().map(str::to_string).ok_or_else(|| {
                HarnessError::InvalidArgs(format!("arg `{key}` must contain strings"))
            })
        })
        .collect()
}

// Validate a finding ID before matching local files
fn validate_finding_id(finding_id: &str) -> Result<(), HarnessError> {
    if finding_id.is_empty()
        || finding_id.contains('/')
        || finding_id.contains('\\')
        || finding_id.chars().any(char::is_control)
    {
        return Err(HarnessError::InvalidArgs(
            "finding_id must be a safe file prefix".into(),
        ));
    }
    Ok(())
}

// Find a finding markdown path by ID prefix
fn find_finding_path(findings_dir: &Path, finding_id: &str) -> Result<PathBuf, HarnessError> {
    let entries = fs::read_dir(findings_dir)?;
    for entry in entries.flatten() {
        let path = entry.path();
        let Some(name) = path.file_name().and_then(|n| n.to_str()) else {
            continue;
        };
        if name.starts_with(finding_id) && name.ends_with(".md") {
            return Ok(path);
        }
    }
    Err(HarnessError::InvalidArgs(format!(
        "finding `{finding_id}` not found"
    )))
}

// Truncate model-visible markdown to the configured cap
fn truncate_model_visible(raw: &str) -> (String, bool) {
    if raw.len() <= MAX_MODEL_VISIBLE_BYTES {
        return (raw.to_string(), false);
    }
    let mut end = MAX_MODEL_VISIBLE_BYTES;
    while !raw.is_char_boundary(end) {
        end -= 1;
    }
    (raw[..end].to_string(), true)
}

// Return file state for status JSON
fn file_state(path: &Path) -> Value {
    match fs::metadata(path) {
        Ok(meta) => json!({
            "exists": true,
            "bytes": meta.len(),
            "path": display_path(path),
        }),
        Err(_) => json!({
            "exists": false,
            "bytes": 0,
            "path": display_path(path),
        }),
    }
}

// Count child directories
fn count_dirs(path: &Path) -> usize {
    fs::read_dir(path)
        .map(|entries| {
            entries
                .filter_map(|entry| entry.ok())
                .filter(|entry| entry.file_type().is_ok_and(|ty| ty.is_dir()))
                .count()
        })
        .unwrap_or(0)
}

// Count files with a specific extension
fn count_files_with_extension(path: &Path, extension: &str) -> usize {
    fs::read_dir(path)
        .map(|entries| {
            entries
                .filter_map(|entry| entry.ok())
                .map(|entry| entry.path())
                .filter(|path| path.extension().is_some_and(|ext| ext == extension))
                .count()
        })
        .unwrap_or(0)
}

// Count files by prefix and suffix
fn count_files_with_prefix_suffix(path: &Path, prefix: &str, suffix: &str) -> usize {
    fs::read_dir(path)
        .map(|entries| {
            entries
                .filter_map(|entry| entry.ok())
                .filter(|entry| {
                    entry
                        .file_name()
                        .to_str()
                        .is_some_and(|name| name.starts_with(prefix) && name.ends_with(suffix))
                })
                .count()
        })
        .unwrap_or(0)
}

// Count lines in a UTF-8 text file
fn count_lines(path: &Path) -> usize {
    fs::read_to_string(path)
        .map(|raw| raw.lines().count())
        .unwrap_or(0)
}

// Parse severity from endpoint args
fn parse_severity(raw: &str) -> Result<Severity, HarnessError> {
    match raw.to_lowercase().as_str() {
        "info" => Ok(Severity::Info),
        "low" => Ok(Severity::Low),
        "medium" => Ok(Severity::Medium),
        "high" => Ok(Severity::High),
        "critical" => Ok(Severity::Critical),
        other => Err(HarnessError::InvalidArgs(format!(
            "unknown severity `{other}`"
        ))),
    }
}

// Return the current UTC time formatted as RFC3339
fn now_rfc3339() -> Result<String, HarnessError> {
    Ok(OffsetDateTime::now_utc().format(&Rfc3339)?)
}

// Parse an inclusive port range
fn parse_ports(raw: &str) -> Result<(u16, u16), HarnessError> {
    let Some((start_raw, end_raw)) = raw.split_once('-') else {
        return Err(HarnessError::InvalidArgs(
            "ports must use start-end format".into(),
        ));
    };
    let start = start_raw
        .parse::<u16>()
        .map_err(|_| HarnessError::InvalidArgs(format!("invalid start port `{start_raw}`")))?;
    let end = end_raw
        .parse::<u16>()
        .map_err(|_| HarnessError::InvalidArgs(format!("invalid end port `{end_raw}`")))?;
    if start == 0 || start > end {
        return Err(HarnessError::InvalidArgs(format!(
            "invalid port range `{raw}`"
        )));
    }
    Ok((start, end))
}

// Normalize a URL or host into a lower-case hostname for scope checks
fn normalize_target(target: &str) -> Result<String, HarnessError> {
    if let Ok(url) = Url::parse(target) {
        return url
            .host_str()
            .map(|host| host.trim_end_matches('.').to_lowercase())
            .ok_or_else(|| HarnessError::InvalidArgs("URL does not contain a host".into()));
    }

    let without_scheme = target
        .strip_prefix("//")
        .unwrap_or(target)
        .split('/')
        .next()
        .unwrap_or(target);
    let without_port = without_scheme
        .split_once(':')
        .map(|(host, _)| host)
        .unwrap_or(without_scheme);
    let normalized = without_port.trim().trim_end_matches('.').to_lowercase();
    if normalized.is_empty() || normalized.chars().any(char::is_whitespace) {
        return Err(HarnessError::InvalidArgs(format!(
            "invalid target `{target}`"
        )));
    }
    Ok(normalized)
}

// Build a compact model-safe request row
fn traffic_record_summary(record: &engagement::TrafficRecord) -> Value {
    json!({
        "id": record.id.clone(),
        "method": record.method.clone(),
        "url": redact_sensitive_url(&record.url),
        "host": record.host.clone(),
        "path": record.path.clone(),
        "params": record.params.clone(),
        "status": record.response.as_ref().map(|response| response.status),
        "mime": record.response.as_ref().and_then(|response| response.mime.clone()),
        "body_len": record.response.as_ref().map(|response| response.body_len),
        "auth_state": record.auth_state.as_str(),
        "source": record.source.clone(),
        "captured_at": record.captured_at.clone(),
    })
}

// Build a bounded model-safe request detail object
fn traffic_record_detail(record: &engagement::TrafficRecord) -> Value {
    json!({
        "id": record.id.clone(),
        "source": record.source.clone(),
        "captured_at": record.captured_at.clone(),
        "method": record.method.clone(),
        "url": redact_sensitive_url(&record.url),
        "host": record.host.clone(),
        "path": record.path.clone(),
        "params": record.params.clone(),
        "request_headers": record.request_headers.clone(),
        "request_body": record.request_body.as_ref().map(|body| json!({
            "len": body.len,
            "sha256": body.sha256.clone(),
            "truncated": body.truncated,
        })),
        "response": record.response.as_ref().map(|response| json!({
            "status": response.status,
            "mime": response.mime.clone(),
            "body_len": response.body_len,
            "body_sha256": response.body_sha256.clone(),
            "redirect_location": response.redirect_location.as_ref().map(|url| redact_sensitive_url(url)),
            "cookie_names": response.cookie_names.clone(),
            "html_title": response.html_title.clone(),
            "json_shape": response.json_shape.clone(),
        })),
        "auth_state": record.auth_state.as_str(),
    })
}

// Render a raw request skeleton without model-visible request body contents
fn model_safe_raw_request(record: &engagement::TrafficRecord) -> String {
    let redacted_url = redact_sensitive_url(&record.url);
    let path = Url::parse(&redacted_url)
        .ok()
        .map(|url| {
            let mut path = url.path().to_string();
            if let Some(query) = url.query() {
                path.push('?');
                path.push_str(query);
            }
            path
        })
        .unwrap_or_else(|| record.path.clone());
    let mut out = format!(
        "{} {path} HTTP/1.1\r\nHost: {}\r\n",
        record.method, record.host
    );
    for header in &record.request_headers {
        if !header.name.eq_ignore_ascii_case("host") {
            out.push_str(&format!("{}: {}\r\n", header.name, header.value));
        }
    }
    out.push_str("\r\n");
    if let Some(body) = &record.request_body {
        out.push_str(&format!(
            "<body omitted: {} bytes sha256={} truncated={}>\n",
            body.len, body.sha256, body.truncated
        ));
    }
    out
}

// Read a stored body blob from inside the engagement workspace
fn read_body_ref(
    engagement: &Engagement,
    body: &engagement::BodyRef,
) -> Result<Vec<u8>, HarnessError> {
    let path = Path::new(&body.path);
    let abs_path = if path.is_absolute() {
        path.to_path_buf()
    } else {
        engagement.root.join(path)
    };
    Ok(fs::read(abs_path)?)
}

// Skip headers that reqwest/session/default request construction owns
fn should_skip_replay_header(name: &str) -> bool {
    matches!(
        name.to_ascii_lowercase().as_str(),
        "host"
            | "content-length"
            | "connection"
            | "authorization"
            | "proxy-authorization"
            | "cookie"
            | "set-cookie"
    )
}

// Convert response headers into string pairs for fingerprinting
fn response_headers_to_pairs(headers: &reqwest::header::HeaderMap) -> Vec<(String, String)> {
    headers
        .iter()
        .map(|(name, value)| {
            (
                name.as_str().to_string(),
                value.to_str().unwrap_or("<binary>").to_string(),
            )
        })
        .collect()
}

// Read at most a bounded response body into memory
async fn read_limited_response_bytes(
    mut response: reqwest::Response,
    limit: usize,
) -> Result<Vec<u8>, HarnessError> {
    let mut body = Vec::new();
    while let Some(chunk) = response.chunk().await? {
        let remaining = limit.saturating_sub(body.len());
        if remaining == 0 {
            break;
        }
        let take = remaining.min(chunk.len());
        body.extend_from_slice(&chunk[..take]);
        if take < chunk.len() {
            break;
        }
    }
    Ok(body)
}

// Redact sensitive query parameter values before returning URLs to model-visible callers
fn redact_sensitive_url(raw: &str) -> String {
    let Ok(mut url) = Url::parse(raw) else {
        return raw.to_string();
    };
    let pairs: Vec<(String, String)> = url
        .query_pairs()
        .map(|(name, value)| {
            let value = if is_sensitive_param(&name) {
                "<redacted>".into()
            } else {
                value.into_owned()
            };
            (name.into_owned(), value)
        })
        .collect();
    if !pairs.is_empty() {
        url.query_pairs_mut().clear().extend_pairs(pairs);
    }
    url.to_string()
}

fn is_sensitive_param(name: &str) -> bool {
    matches!(
        name.to_ascii_lowercase().as_str(),
        "token"
            | "access_token"
            | "refresh_token"
            | "id_token"
            | "auth"
            | "api_key"
            | "key"
            | "session"
            | "password"
            | "code"
    )
}

// Compact an RFC3339 timestamp for filenames
fn safe_timestamp(timestamp: &str) -> String {
    timestamp
        .chars()
        .filter(|c| c.is_ascii_alphanumeric())
        .collect()
}

// Convert a path into a display string
fn display_path(path: &Path) -> String {
    path.display().to_string()
}

// Build a blocked result
fn result_blocked(endpoint: String, risk: RiskClass, policy: &str, reason: &str) -> EndpointResult {
    EndpointResult {
        endpoint,
        status: EndpointStatus::Blocked,
        risk,
        summary: None,
        output_files: Vec::new(),
        evidence_refs: Vec::new(),
        redactions: BTreeMap::new(),
        data: None,
        reason: Some(reason.into()),
        policy: Some(policy.into()),
    }
}

// Build an error result
fn result_error(endpoint: String, risk: RiskClass, policy: &str, reason: &str) -> EndpointResult {
    EndpointResult {
        endpoint,
        status: EndpointStatus::Error,
        risk,
        summary: None,
        output_files: Vec::new(),
        evidence_refs: Vec::new(),
        redactions: BTreeMap::new(),
        data: None,
        reason: Some(reason.into()),
        policy: Some(policy.into()),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use engagement::EngagementMeta;
    use std::fs;
    use std::sync::atomic::{AtomicU64, Ordering};

    // Create a unique temporary engagement root
    fn tmp_parent() -> PathBuf {
        static COUNTER: AtomicU64 = AtomicU64::new(0);
        let n = COUNTER.fetch_add(1, Ordering::Relaxed);
        let p = std::env::temp_dir().join(format!("mg-harness-test-{}-{n}", std::process::id()));
        let _ = fs::remove_dir_all(&p);
        fs::create_dir_all(&p).unwrap();
        p
    }

    // Create a test engagement
    fn test_config() -> HarnessConfig {
        let parent = tmp_parent();
        let meta = EngagementMeta {
            name: "acme".into(),
            target: "example.com".into(),
            created_at: String::new(),
            platform: None,
            url: None,
            tags: Vec::new(),
        };
        Engagement::init(&parent, meta).unwrap();
        HarnessConfig::new(parent)
    }

    // Build a base invocation
    fn invocation(endpoint: &str) -> Invocation {
        Invocation {
            endpoint: endpoint.into(),
            version: Some(HARNESS_VERSION.into()),
            engagement: "acme".into(),
            risk: None,
            reason: None,
            confirmed: false,
            args: Value::Null,
        }
    }

    #[tokio::test]
    async fn engagement_open_returns_workspace_data() {
        let cfg = test_config();
        let result = dispatch(&cfg, invocation("engagement.open")).await;
        assert_eq!(result.status, EndpointStatus::Ok);
        assert_eq!(result.risk, RiskClass::ReadOnly);
        assert!(result.data.unwrap()["exists"]["summary"].is_boolean());
    }

    #[tokio::test]
    async fn engagement_status_returns_counts() {
        let cfg = test_config();
        let result = dispatch(&cfg, invocation("engagement.status")).await;
        assert_eq!(result.status, EndpointStatus::Ok);
        let data = result.data.unwrap();
        assert_eq!(data["counts"]["findings"], 0);
        assert!(data["files"]["audit_log"]["exists"].as_bool().unwrap());
    }

    #[tokio::test]
    async fn scope_check_normalizes_url_hosts() {
        let cfg = test_config();
        let mut inv = invocation("scope.check");
        inv.args = json!({ "target": "https://API.Example.com:443/path" });
        let result = dispatch(&cfg, inv).await;
        assert_eq!(result.status, EndpointStatus::Ok);
        let data = result.data.unwrap();
        assert_eq!(data["normalized_target"], "api.example.com");
        assert_eq!(data["in_scope"], true);
    }

    #[tokio::test]
    async fn scope_check_reports_out_of_scope() {
        let cfg = test_config();
        let mut inv = invocation("scope.check");
        inv.args = json!({ "target": "other.test" });
        let result = dispatch(&cfg, inv).await;
        assert_eq!(result.status, EndpointStatus::Ok);
        assert_eq!(result.data.unwrap()["in_scope"], false);
    }

    #[tokio::test]
    async fn high_active_requires_confirmation() {
        let cfg = test_config();
        let result = dispatch(&cfg, invocation("recon.run")).await;
        assert_eq!(result.status, EndpointStatus::Blocked);
        assert_eq!(result.policy.as_deref(), Some("risk.confirmation_required"));
    }

    #[tokio::test]
    async fn registered_unimplemented_endpoint_is_blocked() {
        let cfg = test_config();
        let result = dispatch(&cfg, invocation("crawl.run")).await;
        assert_eq!(result.status, EndpointStatus::Blocked);
        assert_eq!(result.policy.as_deref(), Some("endpoint.not_implemented"));
    }

    #[tokio::test]
    async fn request_import_search_and_read_round_trip() {
        let cfg = test_config();
        let eng = Engagement::load_named(&cfg.engagements_dir, "acme").unwrap();
        let har_path = cfg.engagements_dir.join("traffic.har");
        fs::write(
            &har_path,
            r#"{
              "log": {"entries": [{
                "startedDateTime": "2026-05-15T00:00:00Z",
                "request": {
                  "method": "GET",
                  "url": "https://api.example.com/v1/users?access_token=secret&id=1",
                  "headers": [{"name":"Authorization","value":"Bearer secret"}],
                  "queryString": [{"name":"id","value":"1"}]
                },
                "response": {
                  "status": 200,
                  "headers": [{"name":"Content-Type","value":"application/json"}],
                  "content": {"mimeType":"application/json","text":"{\"id\":1,\"name\":\"Ada\"}"}
                }
              }]}}
            "#,
        )
        .unwrap();

        let mut import = invocation("request.import");
        import.confirmed = true;
        import.args = json!({
            "file": har_path.display().to_string(),
            "format": "har",
        });
        let import_result = dispatch(&cfg, import).await;
        assert_eq!(
            import_result.status,
            EndpointStatus::Ok,
            "{import_result:?}"
        );
        assert!(eng.traffic_corpus_path().exists());

        let mut search = invocation("request.search");
        search.args = json!({ "host": "api.example.com", "limit": 5 });
        let search_result = dispatch(&cfg, search).await;
        assert_eq!(search_result.status, EndpointStatus::Ok);
        let search_data = search_result.data.unwrap();
        let request_id = search_data["requests"][0]["id"]
            .as_str()
            .unwrap()
            .to_string();
        assert_eq!(search_data["requests"][0]["status"], 200);
        assert!(
            search_data["requests"][0]["url"]
                .as_str()
                .unwrap()
                .contains("access_token=%3Credacted%3E")
        );

        let mut read = invocation("request.read");
        read.args = json!({ "request_id": request_id, "include_raw": true });
        let read_result = dispatch(&cfg, read).await;
        assert_eq!(read_result.status, EndpointStatus::Ok);
        let read_data = read_result.data.unwrap();
        assert_eq!(read_data["request_headers"][0]["value"], "<redacted>");
        assert!(
            read_data["raw_request_template"]
                .as_str()
                .unwrap()
                .contains("<redacted>")
        );
        assert!(
            read_data["raw_request_template"]
                .as_str()
                .unwrap()
                .contains("access_token=%3Credacted%3E")
        );
        assert!(
            read_data["response"]["json_shape"]
                .as_str()
                .unwrap()
                .contains("name:string")
        );
    }

    #[tokio::test]
    async fn finding_create_writes_scoped_draft() {
        let cfg = test_config();
        let mut inv = invocation("finding.create");
        inv.args = json!({
            "title": "Controlled IDOR proof",
            "target": "https://api.example.com/v1/users/2",
            "severity": "high",
            "evidence_refs": ["evidence://acme/replay/one"]
        });
        let result = dispatch(&cfg, inv).await;
        assert_eq!(result.status, EndpointStatus::Ok);
        let path = result.output_files.first().unwrap();
        let markdown = fs::read_to_string(path).unwrap();
        assert!(markdown.contains("title: Controlled IDOR proof"));
        assert!(markdown.contains("severity: high"));
        assert!(markdown.contains("evidence://acme/replay/one"));
    }

    #[tokio::test]
    async fn finding_read_loads_created_markdown() {
        let cfg = test_config();
        let mut create = invocation("finding.create");
        create.args = json!({
            "title": "Readable finding",
            "target": "https://api.example.com/v1/users/2"
        });
        let create_result = dispatch(&cfg, create).await;
        let finding_id = create_result.data.unwrap()["id"]
            .as_str()
            .unwrap()
            .to_string();

        let mut read = invocation("finding.read");
        read.args = json!({ "finding_id": finding_id });
        let read_result = dispatch(&cfg, read).await;
        assert_eq!(read_result.status, EndpointStatus::Ok);
        let data = read_result.data.unwrap();
        assert!(
            data["markdown"]
                .as_str()
                .unwrap()
                .contains("Readable finding")
        );
        assert_eq!(data["truncated"], false);
    }

    #[tokio::test]
    async fn finding_read_rejects_path_like_ids() {
        let cfg = test_config();
        let mut read = invocation("finding.read");
        read.args = json!({ "finding_id": "../escape" });
        let result = dispatch(&cfg, read).await;
        assert_eq!(result.status, EndpointStatus::Error);
        assert_eq!(result.policy.as_deref(), Some("endpoint.error"));
    }

    #[tokio::test]
    async fn finding_create_blocks_out_of_scope_target() {
        let cfg = test_config();
        let mut inv = invocation("finding.create");
        inv.args = json!({
            "title": "Bad target",
            "target": "https://other.test/path"
        });
        let result = dispatch(&cfg, inv).await;
        assert_eq!(result.status, EndpointStatus::Blocked);
        assert_eq!(result.policy.as_deref(), Some("scope.default_deny"));
    }

    #[tokio::test]
    async fn session_set_writes_env_reference_profile() {
        let cfg = test_config();
        let mut inv = invocation("session.set");
        inv.confirmed = true;
        inv.args = json!({
            "token_env": "MG_HARNESS_TOKEN",
            "token_header": "Authorization",
            "token_prefix": "Bearer"
        });

        let result = dispatch(&cfg, inv).await;

        assert_eq!(result.status, EndpointStatus::Ok);
        let path = result.output_files.first().unwrap();
        let raw = fs::read_to_string(path).unwrap();
        assert!(raw.contains("\"token_env\": \"MG_HARNESS_TOKEN\""));
        assert!(!raw.contains("secret"));
    }

    #[tokio::test]
    async fn session_set_rejects_plaintext_secret_args() {
        let cfg = test_config();
        let mut inv = invocation("session.set");
        inv.confirmed = true;
        inv.args = json!({
            "token": "secret",
            "token_env": "MG_HARNESS_TOKEN"
        });

        let result = dispatch(&cfg, inv).await;

        assert_eq!(result.status, EndpointStatus::Error);
        assert!(result.reason.unwrap().contains("not allowed"));
    }

    #[tokio::test]
    async fn session_get_headers_redacts_values() {
        let cfg = test_config();
        let env_name = format!("MG_HARNESS_TOKEN_{}", std::process::id());
        // Set a uniquely named process env var for this header-resolution test.
        unsafe {
            std::env::set_var(&env_name, "secret-token-value");
        }
        let mut set = invocation("session.set");
        set.confirmed = true;
        set.args = json!({ "token_env": env_name });
        let set_result = dispatch(&cfg, set).await;
        assert_eq!(set_result.status, EndpointStatus::Ok);

        let result = dispatch(&cfg, invocation("session.get_headers")).await;

        assert_eq!(result.status, EndpointStatus::Ok);
        let data = result.data.unwrap();
        assert_eq!(data["configured"], true);
        assert_eq!(data["headers"]["authorization"], "<redacted>");
        assert_eq!(data["header_count"], 1);
    }

    #[tokio::test]
    async fn chain_read_loads_analysis_artifacts() {
        let cfg = test_config();
        let eng = Engagement::load_named(&cfg.engagements_dir, "acme").unwrap();
        fs::write(
            eng.recon_dir().join("chain-analysis.json"),
            "{\"analysis_markdown\":\"## Chains\\nNone\"}",
        )
        .unwrap();
        fs::write(eng.recon_dir().join("chain-analysis.md"), "## Chains\nNone").unwrap();

        let result = dispatch(&cfg, invocation("chain.read")).await;

        assert_eq!(result.status, EndpointStatus::Ok);
        let data = result.data.unwrap();
        assert!(
            data["chain_json"]
                .as_str()
                .unwrap()
                .contains("analysis_markdown")
        );
        assert!(data["markdown"].as_str().unwrap().contains("## Chains"));
    }

    #[tokio::test]
    async fn graph_ingest_summary_and_neighbors_round_trip() {
        let cfg = test_config();
        let eng = Engagement::load_named(&cfg.engagements_dir, "acme").unwrap();
        fs::write(
            eng.recon_dir().join("summary.json"),
            r#"{
              "engagement":"acme",
              "target":"example.com",
              "generated_at":"2026-05-15T00:00:00Z",
              "host_count":1,
              "hosts":[{
                "hostname":"api.example.com",
                "ips":["127.0.0.1"],
                "source":"ct_log",
                "http_accessible":true,
                "fingerprint":{"server":"nginx","framework":"express"},
                "open_ports":[80,443],
                "services":["http","https"]
              }]
            }"#,
        )
        .unwrap();

        let ingest_result = dispatch(&cfg, invocation("graph.ingest")).await;
        assert_eq!(ingest_result.status, EndpointStatus::Ok);
        assert!(Path::new(ingest_result.output_files.first().unwrap()).exists());

        let mut summary_inv = invocation("graph.summary");
        summary_inv.args = json!({ "sample_limit": 5 });
        let summary_result = dispatch(&cfg, summary_inv).await;
        assert_eq!(summary_result.status, EndpointStatus::Ok);
        let summary_data = summary_result.data.unwrap();
        assert!(summary_data["node_count"].as_u64().unwrap() >= 3);
        assert!(summary_data["edge_count"].as_u64().unwrap() >= 1);
        assert!(summary_data["node_kinds"]["host"].as_u64().unwrap() >= 2);

        let mut neighbors_inv = invocation("graph.neighbors");
        neighbors_inv.args = json!({
            "kind": "host",
            "key": "example.com",
            "limit": 10,
        });
        let neighbors_result = dispatch(&cfg, neighbors_inv).await;
        assert_eq!(neighbors_result.status, EndpointStatus::Ok);
        let neighbors_data = neighbors_result.data.unwrap();
        assert!(
            neighbors_data["neighbors"]
                .as_array()
                .unwrap()
                .iter()
                .any(|item| item["node"]["label"] == "api.example.com")
        );
    }

    #[tokio::test]
    async fn report_generate_writes_offline_report() {
        let cfg = test_config();
        let eng = Engagement::load_named(&cfg.engagements_dir, "acme").unwrap();
        let finding = Finding {
            id: "2026-05-15-001".into(),
            title: "Open redirect on login".into(),
            severity: Severity::Medium,
            status: Status::Confirmed,
            target: "www.example.com".into(),
            created: "2026-05-15T00:00:00Z".into(),
            body: "## Summary\n\nLogin redirects to arbitrary URLs.\n\n## Steps to reproduce\n\n1. Visit /login?next=https://evil.example\n\n## Impact\n\nPhishing and OAuth chain risk.\n\n## Evidence\n\nGET /login?next=https://evil.example -> 302\n\n## Remediation\n\nAllowlist redirect targets.\n".into(),
        };
        finding.write_to(&eng.findings_dir()).unwrap();
        let mut inv = invocation("report.generate");
        inv.args = json!({
            "finding_id": "2026-05-15-001",
            "offline": true,
            "force": true,
        });

        let result = dispatch(&cfg, inv).await;

        assert_eq!(result.status, EndpointStatus::Ok);
        let data = result.data.unwrap();
        let report_path = data["report_path"].as_str().unwrap();
        assert!(Path::new(report_path).exists());
        assert!(data["cvss_score"].as_f64().unwrap() > 0.0);
    }

    #[tokio::test]
    async fn report_disclose_writes_cve_and_email() {
        let cfg = test_config();
        let eng = Engagement::load_named(&cfg.engagements_dir, "acme").unwrap();
        let finding = Finding {
            id: "2026-05-15-002".into(),
            title: "SQL error on search".into(),
            severity: Severity::High,
            status: Status::Confirmed,
            target: "www.example.com".into(),
            created: "2026-05-15T00:00:00Z".into(),
            body: "## Summary\n\nSearch leaks SQL errors.\n\n## Steps to reproduce\n\n1. GET /search?q='\n\n## Impact\n\nSchema disclosure.\n\n## Evidence\n\n```\ncurl /search?q='\n```\n\n## Remediation\n\nUse parameterized queries.\n".into(),
        };
        finding.write_to(&eng.findings_dir()).unwrap();
        let mut inv = invocation("report.disclose");
        inv.args = json!({
            "finding_id": "2026-05-15-002",
            "vendor": "Acme Corp",
            "contact": "security@acme.example",
            "timeline_days": 60,
            "offline": true,
            "force": true,
        });

        let result = dispatch(&cfg, inv).await;

        assert_eq!(result.status, EndpointStatus::Ok);
        let data = result.data.unwrap();
        let cve_path = data["cve_writeup_path"].as_str().unwrap();
        let email_path = data["disclosure_email_path"].as_str().unwrap();
        assert!(Path::new(cve_path).exists());
        assert!(Path::new(email_path).exists());
        assert_eq!(data["timeline_days"].as_u64().unwrap(), 60);
        let email = fs::read_to_string(email_path).unwrap();
        assert!(email.contains("X-GeistScope-Meta: vendor=Acme Corp; timeline_days=60;"));
        assert!(email.contains("To: security@acme.example"));
    }

    #[tokio::test]
    async fn re_analyze_and_read_round_trip_offline() {
        let cfg = test_config();
        let eng = Engagement::load_named(&cfg.engagements_dir, "acme").unwrap();
        let raw_dir = eng.re_dir().join("libfoo").join("raw");
        fs::create_dir_all(&raw_dir).unwrap();
        fs::write(
            raw_dir.join("parse_header.c"),
            "int parse_header(buf *p) { return p->len; }",
        )
        .unwrap();

        let mut analyze = invocation("re.analyze");
        analyze.args = json!({
            "binary": "libfoo",
            "function": "parse_header",
            "offline": true,
            "force": true,
        });
        let analyze_result = dispatch(&cfg, analyze).await;
        assert_eq!(analyze_result.status, EndpointStatus::Ok);
        let data = analyze_result.data.unwrap();
        assert!(Path::new(data["markdown_path"].as_str().unwrap()).exists());
        assert!(Path::new(data["json_path"].as_str().unwrap()).exists());

        let mut read = invocation("re.read");
        read.args = json!({ "binary": "libfoo", "function": "parse_header" });
        let read_result = dispatch(&cfg, read).await;
        assert_eq!(read_result.status, EndpointStatus::Ok);
        let read_data = read_result.data.unwrap();
        assert!(
            read_data["markdown"]
                .as_str()
                .unwrap()
                .contains("RE Analysis")
        );
        assert_eq!(read_data["json"]["function"], "parse_header");
        assert_eq!(read_data["markdown_truncated"], false);
    }

    #[tokio::test]
    async fn aifuzz_consent_writes_marker_file() {
        let cfg = test_config();
        let mut inv = invocation("aifuzz.consent");
        inv.confirmed = true;
        let result = dispatch(&cfg, inv).await;
        assert_eq!(result.status, EndpointStatus::Ok);
        let path = result.output_files.first().unwrap();
        assert!(Path::new(path).exists());
    }

    #[tokio::test]
    async fn aifuzz_run_rejects_out_of_scope_base_url() {
        let cfg = test_config();
        // Pre-record consent so the call gets past that check
        mg_aifuzz::record_consent(&cfg.engagements_dir, "acme").unwrap();
        let template_path = cfg.engagements_dir.join("aifuzz-template.txt");
        fs::write(
            &template_path,
            "POST /chat HTTP/1.1\nHost: out.invalid\nContent-Type: application/json\n\n{\"q\":\"§INJECT§\"}",
        )
        .unwrap();
        let mut inv = invocation("aifuzz.run");
        inv.confirmed = true;
        inv.args = json!({
            "template": template_path.display().to_string(),
            "base_url": "https://out.invalid",
            "max_attempts": 1,
            "rate_ms": 0,
            "timeout_ms": 500,
        });
        let result = dispatch(&cfg, inv).await;
        assert_eq!(result.status, EndpointStatus::Error);
        assert!(result.reason.unwrap().contains("out.invalid"));
    }

    #[tokio::test]
    async fn exploit_scaffold_writes_tree_offline() {
        let cfg = test_config();
        let desc_path = cfg.engagements_dir.join("cve-desc.md");
        fs::write(&desc_path, "Test CVE: example bug in libxyz < 1.2.3.").unwrap();
        let env_path = cfg.engagements_dir.join("target-env.json");
        fs::write(&env_path, r#"{"product":"libxyz","version":"1.2.0"}"#).unwrap();

        let mut inv = invocation("exploit.scaffold");
        inv.args = json!({
            "cve": "CVE-2026-9999",
            "cve_description": desc_path.display().to_string(),
            "target_env": env_path.display().to_string(),
            "offline": true,
            "force": true,
        });

        let result = dispatch(&cfg, inv).await;

        assert_eq!(result.status, EndpointStatus::Ok);
        let data = result.data.unwrap();
        let exploit_dir = data["exploit_dir"].as_str().unwrap();
        let runbook = data["runbook_path"].as_str().unwrap();
        assert!(
            Path::new(exploit_dir)
                .join("src")
                .join("scanner.rs")
                .exists()
        );
        assert!(Path::new(runbook).exists());
        assert_eq!(data["crate_name"], "exploit_cve_2026_9999");
    }

    #[test]
    fn port_parser_rejects_bad_ranges() {
        assert!(parse_ports("1-1024").is_ok());
        assert!(parse_ports("0-1024").is_err());
        assert!(parse_ports("9000-80").is_err());
        assert!(parse_ports("443").is_err());
    }

    #[test]
    fn model_visible_truncation_respects_utf8() {
        let raw = format!("{}é", "a".repeat(MAX_MODEL_VISIBLE_BYTES));
        let (truncated, did_truncate) = truncate_model_visible(&raw);
        assert!(did_truncate);
        assert!(truncated.is_char_boundary(truncated.len()));
    }

    #[test]
    fn subprocess_tools_table_is_consistent() {
        assert_eq!(SUBPROCESS_TOOLS.len(), 65);

        // Endpoint names unique
        let mut names: Vec<&str> = SUBPROCESS_TOOLS.iter().map(|t| t.endpoint).collect();
        names.sort_unstable();
        let n = names.len();
        names.dedup();
        assert_eq!(
            names.len(),
            n,
            "duplicate endpoint name in SUBPROCESS_TOOLS"
        );

        // (binary, subcommand) pairs unique — merged binaries like mg-artifact-audit
        // host multiple endpoints distinguished by subcommand
        let mut pairs: Vec<(&str, Option<&str>)> = SUBPROCESS_TOOLS
            .iter()
            .map(|t| (t.binary, tool_subcommand_for_endpoint(t.endpoint)))
            .collect();
        pairs.sort();
        let p = pairs.len();
        pairs.dedup();
        assert_eq!(
            pairs.len(),
            p,
            "duplicate (binary, subcommand) pair in SUBPROCESS_TOOLS"
        );

        // Every entry surfaces in the registry and round-trips through the binary lookup
        let reg_names: Vec<&str> = registry().iter().map(|s| s.name).collect();
        for tool in SUBPROCESS_TOOLS {
            assert!(
                reg_names.contains(&tool.endpoint),
                "registry missing {}",
                tool.endpoint
            );
            assert_eq!(tool_binary_for_endpoint(tool.endpoint), tool.binary);
            assert!(subprocess_tool_for(tool.endpoint).is_some());
        }
    }

    #[test]
    fn prune_candidates_are_not_default_exposure() {
        let specs = registry();
        for endpoint in [
            "brute.run",
            "snmp.brute",
            "dns.rebind",
            "exploit.scaffold",
            "privesc.linux",
            "privesc.windows",
            "loot.run",
        ] {
            let spec = specs.iter().find(|s| s.name == endpoint).unwrap();
            assert_ne!(
                spec.exposure,
                ToolExposure::DefaultProfile,
                "{endpoint} should not be default-visible"
            );
            assert!(
                spec.repurpose.is_some(),
                "{endpoint} needs a repurpose note before pruning"
            );
        }
    }

    #[test]
    fn collapsed_pack_metadata_groups_related_tools() {
        let specs = registry();
        let ssrf = specs.iter().find(|s| s.name == "ssrf.scan").unwrap();
        let brute = specs.iter().find(|s| s.name == "brute.run").unwrap();
        let loot = specs.iter().find(|s| s.name == "loot.run").unwrap();

        assert_eq!(ssrf.pack, ToolPack::VulnScan);
        assert_eq!(brute.pack, ToolPack::IdentityAudit);
        assert_eq!(loot.pack, ToolPack::RedteamLab);
    }

    #[test]
    fn artifact_audit_endpoint_is_wired() {
        let tool = subprocess_tool_for("artifact.audit").expect("artifact.audit registered");
        assert_eq!(tool.binary, "mg-artifact-audit");
        assert_eq!(tool_subcommand_for_endpoint("artifact.audit"), Some("audit"));

        let specs = registry();
        let spec = specs
            .iter()
            .find(|s| s.name == "artifact.audit")
            .expect("artifact.audit in registry");
        assert_eq!(spec.pack, ToolPack::ArtifactAudit);
        assert_eq!(spec.exposure, ToolExposure::DefaultProfile);
        assert_eq!(spec.risk, RiskClass::PassiveRemote);

        // The six legacy per-type endpoints also share the merged binary
        for (endpoint, expected_sub) in &[
            ("js.analyze", "js"),
            ("sourcemap.fetch", "sourcemap"),
            ("apikey.extract", "apikey"),
            ("metadata.extract", "metadata"),
            ("apk.analyze", "apk"),
            ("ipa.analyze", "ipa"),
        ] {
            let tool = subprocess_tool_for(endpoint).unwrap();
            assert_eq!(tool.binary, "mg-artifact-audit", "{endpoint}");
            assert_eq!(
                tool_subcommand_for_endpoint(endpoint),
                Some(*expected_sub),
                "{endpoint}"
            );
        }
    }
}
