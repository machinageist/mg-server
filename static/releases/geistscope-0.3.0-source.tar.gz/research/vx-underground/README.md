# VX-Underground research corpus (safe papers only)

Source: vxunderground/VXUG-Papers on GitHub. This corpus intentionally excludes MalwareSourceCode, VX-API, packed samples, binaries, and exploit payload repositories. Use it for defensive/offensive-security research notes and GeistScope skill grounding, not for execution.

| Slug | Source | Bytes | SHA-256 |
|---|---:|---:|---|
| `windows-syscall-evasion` | `Hells Gate/HellsGate.pdf` | 381301 | `71f9b7f6f4d138f5…` |
| `av-minifilter-enumeration` | `Identifying Antivirus Software by enumerating Minifilter String Names/IdentifyingAntivirusSoftwarebyenumeratingMinifilterStringNames.pdf` | 166433 | `b28d7431d751b016…` |
| `windows-context-menu-persistence` | `The Persistence Series/Commandeering Context Menu Entries/CommandeeringContextMenuEntries.pdf` | 552118 | `415f8f4a50090124…` |
| `windows-frozen-malware-persistence` | `The Persistence Series/Cryogenically Frozen Malware/Cryogenically Frozen Malware.pdf` | 350843 | `d59c3b1a282d5822…` |
| `windows-hkcu-run-key-masquerade` | `The Persistence Series/Masquerading the HKCU Run Key/MasqueradingtheHKCURunKey.pdf` | 166701 | `0500e1b0675a21f7…` |
| `windows-recycle-bin-persistence` | `The Persistence Series/Persistence via Recycle Bin/Persistence_via_Recycle_Bin.pdf` | 164500 | `4a310e68cad4176a…` |
| `windows-virtualization-abuse` | `Weaponizing Windows Virtualization/WeaponizingWindowsVirtualization.pdf` | 249170 | `85b91f26523e6b04…` |
| `ssh-worm-propagation` | `Wormable SSH/Wormable SSH.pdf` | 154397 | `45a453907209f7ec…` |
| `usb-propagation` | `USB Propagation/USB Propagation.pdf` | 283684 | `141fc7b9189adac0…` |
| `android-app-infection` | `Infecting Android Applications The New Way/InfectingAndroidApplicationsTheNewWay.pdf` | 5169560 | `cf98b3ab7461ce5b…` |
| `process-enumeration-alternative` | `An Alternative Method To Enumerate Processes.pdf` | 182530 | `4c2ad3b7d216f4e6…` |
| `windows-power-api-abuse` | `Abusing the Windows Power Management API/AbusingtheWindowsPowerManagementAPI.pdf` | 179197 | `1c96b08c630bfdda…` |
| `fake-entry-point-trick` | `The Fake Entry Point Trick.txt` | 4324 | `68b2e30b7cf0243f…` |
