# GeistScope tool-chest rationalization

Date: 2026-05-22
Scope: first-pass evaluation of the current GeistScope crate/harness surface plus the active Hermes CLI toolsets used while developing it.

## Executive summary

GeistScope has the right spine: engagement workspace, request corpus, graph, harness, replay/fuzz/report, and a few high-signal recon tools. The sprawl comes from the 60+ one-binary/one-endpoint additions. Most are only ~300-800 lines each, but each crate adds build/test/docs/harness/UX surface area and makes the AI tool catalog noisy.

Recommendation: do not delete capability blindly. Collapse the long tail into fewer domain engines with subcommands, hide hazardous/rare modules behind profiles, and prune tools that duplicate stronger engines or create legal/operational risk without a clear GeistScope use case.

Target shape:

- Core always-on: engagement, scope, request corpus, crawl, probe, replay, fuzz, report, graph, harness, timeline/diff.
- Optional packs: recon/osint, web-vuln, identity/auth, cloud/container, mobile/binary, endpoint/post-exploitation, notifications/OOB.
- Agent catalog: expose packs and planners by default; expose individual sharp tools only after operator chooses a pack or hypothesis.

## Current high-level inventory

Core documented binaries:

- mg-engagement, mg-recon, mg-crawl, mg-probe, mg-fuzz, mg-replay, mg-report, mg-tui, mg-harness
- security-graph, payload-engine, session, http-client, llm-client, corpus-builder
- ai-prioritize, mg-recopilot, mg-aifuzz, mg-exploitgen

Harness subprocess table currently contributes ~67 tool endpoints. The list is table-driven in:

- `crates/mg-harness/src/lib.rs::SUBPROCESS_TOOLS`

## Combine into domain engines

### 1. Combine passive OSINT/recon into `mg-reconx`

Merge or route these behind one binary with subcommands:

- `mg-whois`
- `mg-shodan`
- `mg-dns-history`
- `mg-breach`
- `mg-social`
- `mg-google-dork`
- `mg-github`
- `mg-cloud-enum`
- `mg-dns-enum`
- `mg-cname-chain`
- `mg-takeover`

Why: these are target-intelligence collectors with similar inputs/outputs and passive/low-active risk. Keeping them as separate model-visible endpoints bloats selection without improving reasoning.

Suggested subcommands:

```text
mg-reconx dns
mg-reconx passive-dns
mg-reconx whois
mg-reconx takeover
mg-reconx github
mg-reconx cloud-storage
mg-reconx osint
```

Default agent endpoint should be `reconx.run` with a mode enum, not 10+ separate tools.

### 2. Combine HTTP posture/protocol checks into `mg-protocol-audit`

Merge:

- `mg-tls-scan`
- `mg-ssh-audit`
- `mg-http2`
- `mg-grpc`
- `mg-websocket`
- `mg-smtp`
- `mg-smb`
- `mg-snmp`
- maybe `mg-udp-scan`

Why: they are service-protocol audits. Shared needs: host/port, scope check, timeout, banner parsing, structured finding output.

Caution: keep brute-force-ish modes disabled by default. `snmp.brute` should become `snmp.audit` with brute force requiring an explicit `--active-bruteforce` flag.

### 3. Combine web vulnerability scanners into `mg-vuln-scan`

Merge:

- `mg-xss`
- `mg-sqli`
- `mg-ssrf`
- `mg-ssti`
- `mg-xxe`
- `mg-traversal`
- `mg-redirect`
- `mg-csrf`
- `mg-cmdinject`
- `mg-cache-poison`
- `mg-proto-pollute`
- `mg-deser`
- `mg-cors-exploit`

Why: these are all request-corpus driven payload probes. They should share request selection, rate limits, OOB allocation, evidence writing, and confirmation policy. The current per-bug binaries look tidy but force duplicated HTTP/finding/risk code.

Suggested model-visible endpoints:

```text
vuln.plan   # read-only; selects candidates and bug classes
vuln.run    # active; requires confirmation and explicit classes
```

The operator can still run `mg-vuln-scan --class ssrf,xss --request-id ...` from CLI.

### 4. Combine identity/auth/session tools into `mg-identity-audit`

Merge:

- `mg-jwt`
- `mg-oauth`
- `mg-session-audit`
- `mg-authz`
- `mg-brute` (but heavily gated)

Why: authentication and authorization bugs interact. A single engine can model roles, tokens, sessions, replay sets, and account fixtures better than isolated tools.

Pruning note: `mg-brute` should not be agent-visible by default. Keep it only as a manual operator subcommand or replace it with passive rate-limit/lockout analysis.

### 5. Combine cloud/container checks into `mg-cloud-audit`

Merge:

- `mg-aws`
- `mg-gcp`
- `mg-azure`
- `mg-serverless`
- `mg-k8s`
- `mg-docker`

Why: same chain shape: metadata access, exposed control plane, credentials, permissions, blast radius. One graph-aware engine can score cloud impact better.

Model endpoint should be `cloud.chain` with provider enum and evidence references, not one endpoint per provider.

### 6. Combine artifact analysis into `mg-artifact-audit` *(landed 2026-05-22)*

The six artifact analyzers — `mg-js-analyze`, `mg-sourcemap`, `mg-apikey`,
`mg-metadata`, `mg-apk`, `mg-ipa` — are now merged into a single
subcommand-routed binary at `crates/mg-artifact-audit`. The six legacy
crates are deleted; the harness shells out to `mg-artifact-audit <sub>`
under the original endpoint names (`js.analyze`, `apikey.extract`, etc.),
plus a new `artifact.audit` endpoint that runs multiple types per call.

`SubprocessTool.binary` for the six rows is `mg-artifact-audit`; a new
`tool_subcommand_for_endpoint` lookup in `mg-harness/src/lib.rs` inserts
the subcommand as the first arg. Per-type endpoints stay default-visible
alongside `artifact.audit` (per the rationalization decision to keep both).

Future work for this pack:

- Static RE handoff to `mg-recopilot` (binary/string extraction)
- The VX-derived skills created in this slice fit here:
  - `reverse-engineering-evasion-triage`
  - `mobile-supply-chain-trojanization`
  - `malware-persistence-triage`

### 7. Collapse OOB/notification/event tools into one service

Merge:

- `mg-oob`
- `mg-notify`
- callback-related pieces of SSRF/XXE/CMDi/SQLi scanners

Why: callback allocation, polling, and notifications are infrastructure, not separate attack tools. The agent should ask for `oob.allocate` / `oob.poll`; listeners should be managed by a service or engagement state.

## Repurpose before pruning

Rule: do not delete capability until its safe pieces are available under the target pack. Hide sharp or noisy tools from the default agent-visible catalog first, repurpose defensive parsers/checks into pack engines, then remove the standalone endpoint once the replacement is tested.

The harness now exposes `ToolPack`, `ToolExposure`, and optional `repurpose` metadata in `endpoint.registry`. This is an inventory/profile layer only; dispatch behavior is intentionally unchanged in the first safe slice.

| Tool | Current exposure | Repurpose target before pruning | Reason |
|---|---|---|---|
| `mg-brute` / `brute.run` | retired-pending-pack | `mg-identity-audit`: rate-limit, lockout, credential-stuffing exposure analysis; no default brute-force affordance | High legal/lockout risk; passive/fixture-based identity checks are safer and higher signal |
| `mg-snmp` brute mode / `snmp.brute` | retired-pending-pack | `mg-protocol-audit`: conservative SNMP exposure/config audit; brute force only behind explicit operator flag | Community-string brute force is noisy and scope-sensitive |
| `mg-loot` / `loot.run` | lab-only | `mg-artifact-audit`: evidence inventory, redaction helpers, safe local artifact parsing | Post-exploitation loot collection is outside normal bug-bounty flow and dangerous for an AI catalog |
| `mg-privesc-linux` / `mg-privesc-windows` | lab-only | `redteam-lab` and defensive persistence triage: local checklist/artifact inventory only unless lab profile is enabled | Useful for owned labs, not default GeistScope; require explicit host ownership |
| `mg-dns-rebind` / `dns.rebind` | retired-pending-pack | `mg-vuln-scan`: SSRF/OOB planning mode gated as lab/research support | Payload generation is niche and can confuse default prioritization |
| `mg-exploitgen` / `exploit.scaffold` | lab-only | `redteam-lab`: CVE reproduction scaffolding only | Keep useful reproduction workflow while avoiding default exploit-building affordance |
| `mg-notify` / `notify.start` | service-internal | eventing/OOB service infrastructure | Notification listener is infrastructure, not a scan category |
| `mg-oob` / `oob.start` | advanced-profile | `mg-vuln-scan`: managed callback allocation/polling for SSRF/injection confirmation | OOB is shared scanner infrastructure, not a standalone hypothesis |
| `mg-google-dork` | optional/manual | `mg-reconx`: query generation and configured API-backed collection | Search-engine scraping can be brittle; better as a query generator unless configured |
| `mg-breach` | optional/manual | `mg-reconx`: consent-gated exposure lookup | Sensitive data lookup needs consent and API constraints |

## Keep as core/default

These should remain prominent because they form the GeistScope operating system:

- `mg-engagement`
- `mg-harness`
- `mg-tui`
- `mg-recon` (or wrapper around recon packs)
- `mg-crawl`
- `mg-probe`
- `mg-replay`
- `mg-fuzz` / future `mg-vuln-scan`
- `mg-report`
- `security-graph`
- `request.import`, `request.search`, `request.read`, `request.replay`
- `graph.ingest`, `graph.summary`, `graph.neighbors`
- `ai-prioritize`
- `mg-timeline`, `mg-diff`

## Harness UX recommendation

The first catalog layer is implemented in `mg-harness chat` as `--tool-profile`:

```text
profile: default
  default_profile endpoints only; hides retired, lab-only, service-internal, and destructive tools

profile: advanced
  default_profile + advanced_profile endpoints such as OOB and AI fuzzing helpers

profile: lab
  all implemented endpoints except service_internal; destructive tools still require --unsafe-mode
```

`endpoint.registry` exposes the metadata that drives this (`pack`, `exposure`,
and optional `repurpose`). The model sees fewer high-level tools by default.
The operator can expand to advanced or lab when the evidence supports it.

Future pack-specific profiles should still collapse the visible surface toward:

```text
profile: web-vuln
  vuln.plan, vuln.run, oob.allocate, oob.poll

profile: osint
  reconx.run, artifact.audit

profile: cloud
  cloud.audit, cloud.chain

profile: mobile-binary
  artifact.audit, apk.analyze, ipa.analyze, re.analyze
```

## Hermes development toolsets

Current Hermes CLI has many enabled toolsets: web, browser, terminal, file, code_execution, vision, image_gen, tts, skills, todo, memory, session_search, clarify, delegation, cronjob, messaging, computer_use.

For GeistScope coding/research sessions, a leaner default would be:

- Keep: terminal, file, code_execution, skills, todo, session_search, memory, clarify, delegation, web/browser when research is requested.
- Disable by default for coding sessions: image_gen, tts, messaging, computer_use.
- Keep cronjob only when scheduling/background automation is explicitly requested.

That change affects future Hermes sessions, not this one. Use `hermes tools` or `hermes tools disable <toolset>` and start a new session.

## Next slice proposal

1. ~~Pilot `mg-artifact-audit` as the first physical merge.~~ **Landed 2026-05-22.** See section 6 above.
2. Merge `mg-vuln-scan` next because it gives the biggest reduction in model-visible active tools.
3. Add pack-specific planner endpoints (`vuln.plan`, `reconx.run`) once the domain engines exist, then remove the retired standalone affordances after replacement tests pass.
